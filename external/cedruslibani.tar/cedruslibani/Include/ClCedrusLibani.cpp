#include "ClCedrusLibani.hpp"

using namespace Mori;

ClCedrusLibani::ClCedrusLibani(Mori::CEDRUS_LIBANI_UNSIGNED_INT p_memory_pool_size, Mori::CEDRUS_LIBANI_UNSIGNED_INT p_number_of_data_tables, Mori::CEDRUS_LIBANI_UNSIGNED_INT p_number_of_virtual_data_block)
{
    this->m_flag_is_usable = false;

    if(p_memory_pool_size == 0 || p_number_of_data_tables == 0 || p_number_of_virtual_data_block == 0)
    {
        return;
    }

    /* 
        We round of the division to compute the allocation size per datatable
        See https://stackoverflow.com/questions/2745074/fast-ceiling-of-an-integer-division-in-c-c
    */
    Mori::CEDRUS_LIBANI_UNSIGNED_INT allocation_size_per_data_table =  1 + ((p_memory_pool_size - 1) / p_number_of_data_tables);

    std::vector< std::shared_ptr<Komu::ClDataTable> > data_tables;
    for(Mori::CEDRUS_LIBANI_UNSIGNED_INT i=0;i<p_number_of_data_tables;i++)
    {
        std::shared_ptr<Komu::ClDataTable> tmp_data_table = std::make_shared<Komu::ClDataTable>();
        //tmp_data_table->m_memory_pool = new Komu::KOMU_BYTE[allocation_size_per_data_table];
        //tmp_data_table->m_memory_pool_size = allocation_size_per_data_table;  
        //std::memset(tmp_data_table->m_memory_pool.get(),0,allocation_size_per_data_table); 
        if(tmp_data_table->Initialize(allocation_size_per_data_table) != 1)
        {
             //std:cout << "Error initializing komu dtaa table" << std::endl;
             return;
        }
        data_tables.push_back(tmp_data_table);    
        this->m_node_values_data_table_ids.push_back(data_tables.size()-1); 
    }

    /*
        Create 1 data table for the internal tree memory, that will handle relationship, etc.
    */
    std::shared_ptr<Komu::ClDataTable> tmp_data_table = std::make_shared<Komu::ClDataTable>();
    if(tmp_data_table->Initialize(allocation_size_per_data_table) != 1)
    {
         //std:cout << "Error initializing komu dtaa table" << std::endl;
         return;
    }

    //tmp_data_table->m_memory_pool = new Komu::KOMU_BYTE[allocation_size_per_data_table];
    //tmp_data_table->m_memory_pool_size = allocation_size_per_data_table;  
    //std::memset(tmp_data_table->m_memory_pool.get(),0,allocation_size_per_data_table); 
    data_tables.push_back(tmp_data_table);    

    this->m_internal_buffer_data_table_ids.push_back(data_tables.size()-1);

    /*
        It takes ~5 tree virtual blocks per standard value virtual block
    */
    p_number_of_virtual_data_block *= 5;


    std::shared_ptr<Komu::ClVirtualAddressTable> virtual_address_table = std::make_shared<Komu::ClVirtualAddressTable>(p_number_of_virtual_data_block);
    this->m_komu_instance = std::make_shared<Komu::ClKomu>(virtual_address_table, data_tables);

    this->m_first_node = 0;
    this->m_last_node = 0;

    this->m_flag_is_usable = true;

    Mori::NODE_ID first_node = 0;
    if(this->CreateNode(first_node) < 1)
    {
        this->m_flag_is_usable = false;
        return;
    }
    this->m_first_node = first_node;

    Mori::NODE_ID last_node = 0;
    if(this->CreateNode(last_node) < 1)
    {
        this->m_flag_is_usable = false;
        return;
    }
    this->m_last_node = last_node;    
}

ClCedrusLibani::~ClCedrusLibani()
{
}

bool ClCedrusLibani::IsUsable()
{
    return this->m_flag_is_usable;
}

Mori::NODE_ID ClCedrusLibani::GetFirstNode()
{
    return this->m_first_node;
}

Mori::NODE_ID ClCedrusLibani::GetLastNode()
{
    return this->m_last_node;
}

std::vector< Komu::KOMU_UNSIGNED_INT > ClCedrusLibani::GetDataTableIDsUsedForInternalStorage()
{
    return this->m_internal_buffer_data_table_ids;
}  

std::vector< Komu::KOMU_UNSIGNED_INT > ClCedrusLibani::GetDataTableIDsUsedForNodeValueStorage()
{
    return this->m_node_values_data_table_ids;
}


int ClCedrusLibani::RemoveRelationshipToFirstNode(Mori::NODE_ID p_node_id)
{
    std::vector<Mori::NODE_ID> current_parents;
    int result = this->GetNodeParents(p_node_id,current_parents);
    if(result < 1)
    {
        return -1;
    }

    for(Mori::CEDRUS_LIBANI_UNSIGNED_INT i=0;i<current_parents.size();i++)
    {
        if(current_parents[i] == this->m_first_node)
        {
            result = this->RemoveParentFromNode(p_node_id,this->m_first_node);
            if(result < 1)
            {
                return -2;
            }  

            result = this->RemoveChildFromNode(this->m_first_node,p_node_id);
            if(result < 1)
            {
                return -3;
            }              

            break;
        }
    }

    return 1;
}
int ClCedrusLibani::RemoveRelationshipToLastNode(Mori::NODE_ID p_node_id)
{
    std::vector<Mori::NODE_ID> current_children;
    int result = this->GetNodeChildren(p_node_id,current_children);
    if(result < 1)
    {
        return -1;
    }

    for(Mori::CEDRUS_LIBANI_UNSIGNED_INT i=0;i<current_children.size();i++)
    {
        if(current_children[i] == this->m_last_node)
        {
            result = this->RemoveChildFromNode(p_node_id,this->m_last_node);
            if(result < 1)
            {
                return -2;
            }  

            result = this->RemoveParentFromNode(this->m_last_node,p_node_id);
            if(result < 1)
            {
                return -2;
            }              

            break;
        }
    }

    return 1;
}


int ClCedrusLibani::AddRelationshipToFirstNode(Mori::NODE_ID p_node_id)
{
    int result = this->AddChildToNode(this->m_first_node,p_node_id, Mori::NODE_LINK_TYPE_STANDARD);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::AddRelationshipToFirstNode] AddChildToNode returned : " << result << std::endl;
        return -1;
    } 

    result = this->AddParentToNode(p_node_id, this->m_first_node, Mori::NODE_LINK_TYPE_STANDARD);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::AddRelationshipToFirstNode] AddParentToNode returned : " << result << std::endl;
        return -2;
    }     

    return 1;
}

int ClCedrusLibani::AddRelationshipToLastNode(Mori::NODE_ID p_node_id)
{
    int result = this->AddChildToNode(p_node_id, this->m_last_node,Mori::NODE_LINK_TYPE_STANDARD);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::AddRelationshipToLastNode] AddChildToNode returned : " << result << std::endl;
        return -1;
    } 

    result = this->AddParentToNode(this->m_last_node, p_node_id, Mori::NODE_LINK_TYPE_STANDARD);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::AddRelationshipToLastNode] AddParentToNode returned : " << result << std::endl;
        return -2;
    } 

    return 1;
}

int ClCedrusLibani::GetAllNodeIDs(std::vector<Mori::NODE_ID>& p_result)
{
    if(!this->m_flag_is_usable)
    {
        return -1;
    }   

    Mori::NODE_ID current_node = this->GetFirstNode();
    p_result.push_back(current_node);


    std::vector<Mori::NODE_ID> current_nodes;
    current_nodes.push_back(current_node);

    std::vector<Mori::NODE_ID> current_nodes_children;
    
    do
    {
        current_nodes_children.clear();        
        if(this->GetNodesChildren(current_nodes,current_nodes_children)<1)
        {
            return -2;
        }

        p_result.insert( p_result.end(), current_nodes_children.begin(), current_nodes_children.end() );
        current_nodes = current_nodes_children;

    }while(current_nodes_children.size()>0);


    std::sort(p_result.begin(), p_result.end());
    auto last = std::unique(p_result.begin(), p_result.end());
    p_result.erase(last, p_result.end()); 
    
    return 1;
}

std::shared_ptr<Komu::ClKomu> ClCedrusLibani::GetUnderlayingMemoryManagerInstance()
{
    return this->m_komu_instance;
}

int ClCedrusLibani::CreateNode(Mori::NODE_ID& po_node_id)
{
    if(!this->m_flag_is_usable)
    {
        return -1;
    }

    Komu::KOMU_UNSIGNED_INT node_buffer_id = 0;
    int result = this->m_komu_instance->CreateVirtualBufferFromDataTableGroup(this->m_internal_buffer_data_table_ids, sizeof(Mori::ClNode),node_buffer_id);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::CreateNode] CreateVirtualBuffer returned : " << result << std::endl;
        return -2;
    }  

    Komu::KOMU_UNSIGNED_INT node_value_buffer_id = 0;
    result = this->m_komu_instance->CreateVirtualBufferFromDataTableGroup(this->m_node_values_data_table_ids,16,node_value_buffer_id);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::CreateNode] CreateVirtualBuffer returned : " << result << std::endl;
        return -3;
    }     
    

    Komu::KOMU_UNSIGNED_INT parent_buffer_id = 0;
    result = this->m_komu_instance->CreateVirtualBufferFromDataTableGroup(this->m_internal_buffer_data_table_ids,sizeof(Mori::ClNodeLink),parent_buffer_id);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::CreateNode] CreateVirtualBuffer returned : " << result << std::endl;
        return -4;
    } 
    this->m_komu_instance->SetVirtualBufferData(parent_buffer_id,0);


    Komu::KOMU_UNSIGNED_INT child_buffer_id = 0;
    result = this->m_komu_instance->CreateVirtualBufferFromDataTableGroup(this->m_internal_buffer_data_table_ids,sizeof(Mori::ClNodeLink),child_buffer_id);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::CreateNode] CreateVirtualBuffer returned : " << result << std::endl;
        return -5;
    }  
    this->m_komu_instance->SetVirtualBufferData(child_buffer_id,0);     

    Mori::ClNode new_node;
    new_node.m_value_virtual_buffer_id = node_value_buffer_id;
    new_node.m_number_of_children = 0;
    new_node.m_number_of_parents = 0;
    new_node.m_children_virtual_buffer_id = child_buffer_id;
    new_node.m_parents_virtual_buffer_id = parent_buffer_id;   

    /*
    std::cout << "New node " << node_buffer_id << std::endl;
    std::cout << "   Value VBID " << node_value_buffer_id << std::endl;
    std::cout << "   Children array VBID " << child_buffer_id << std::endl;
    std::cout << "   Parents VBID " << parent_buffer_id << std::endl;
    std::cout << std::endl << std::endl;        
    */

    result = this->m_komu_instance->SetVirtualBufferData(node_buffer_id,(void*)&new_node, sizeof(new_node), this->m_internal_buffer_data_table_ids);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::CreateNode] SetVirtualBufferData returned : " << result << std::endl;
        return -6;
    } 

    if(this->m_first_node > 0 && this->m_last_node > 0)
    {
        result = this->AddRelationshipToFirstNode(node_buffer_id);
        if(result < 1)
        {
            std::cout << "[ClCedrusLibani::CreateNode] Could not link new code with first node : " << result << std::endl;
            return -7;        
        } 

        result = this->AddRelationshipToLastNode(node_buffer_id);
        if(result < 1)
        {
            std::cout << "[ClCedrusLibani::CreateNode] Could not link new code with last node : " << result << std::endl;
            return -8;        
        } 
    }


    po_node_id = node_buffer_id;


    return 1;
}

int ClCedrusLibani::DeleteNode(Mori::NODE_ID p_node_id)
{
    //std::cout << "DeleteNode : Still need to implement the relationship destroyer in this method" << std::endl;
    if(!this->m_flag_is_usable)
    {
        return -1;
    }

    if(p_node_id == this->m_first_node || p_node_id == this->m_last_node)
    {
        return -2;
    }

    int result = this->m_komu_instance->DeleteVirtualBuffer(p_node_id);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::DeleteNode] DeleteVirtualBuffer returned : " << result << std::endl;
        return -3;
    }    

    return 1;  
}

int ClCedrusLibani::GetNodeChildren(Mori::NODE_ID p_node_id, std::vector<Mori::NODE_ID>& po_children)
{
    if(!this->m_flag_is_usable)
    {
        return -1;
    }

    Mori::ClNode parent_node;
    void* parent_node_pointer = &parent_node;
    Komu::KOMU_UNSIGNED_INT written_bytes = 0;
    
    //Load the ClNode's content
    int result = this->m_komu_instance->GetVirtualBufferData(p_node_id,parent_node_pointer,sizeof(parent_node),written_bytes);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::GetNodeChildren] GetVirtualBufferData returned : " << result << std::endl;
        return -2;
    }   

    if(parent_node.m_number_of_children == 0)
    {
        //std::cout << "[ClCedrusLibani::GetNodeChildren] No children detected for node id " << p_node_id << std::endl;
        po_children.clear();
        return 1;
    }

    //Load the ClNode->m_children_virtual_buffer_id's content
    Mori::CEDRUS_LIBANI_UNSIGNED_INT new_children_buffer_size = sizeof(Mori::ClNodeLink)*parent_node.m_number_of_children;

    //UNIQUE_PTR class will free our newly allocated buffer once it's destroyed
    std::unique_ptr<Komu::KOMU_BYTE[]> children_buffer_manager(new Komu::KOMU_BYTE[new_children_buffer_size]);

    Komu::KOMU_BYTE* new_children_buffer = children_buffer_manager.get();
    void* new_children_buffer_pointer = (void*)new_children_buffer;

    result = this->m_komu_instance->GetVirtualBufferData(parent_node.m_children_virtual_buffer_id,new_children_buffer_pointer,new_children_buffer_size,written_bytes);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::GetNodeChildren] GetVirtualBufferData returned : " << result << std::endl;
        return -3;
    }  

    if(written_bytes == 0)
    {
        return -4;
    }

    Mori::ClNodeLink* all_children = (Mori::ClNodeLink*)new_children_buffer;
    for(Mori::CEDRUS_LIBANI_UNSIGNED_INT i=0;i<parent_node.m_number_of_children;i++)
    {
        Mori::ClNodeLink* current_child = all_children + i;
        po_children.push_back(current_child->p_child_node_id);
    }

    return 1;
}

int ClCedrusLibani::GetNodesChildren(std::vector<Mori::NODE_ID>& p_nodes, std::vector<Mori::NODE_ID>& po_children)
{
    std::unordered_set<Mori::NODE_ID> children_set;
    for(Mori::CEDRUS_LIBANI_UNSIGNED_INT i=0;i<p_nodes.size();i++)
    {
        std::vector<Mori::NODE_ID> node_children;
        int result = this->GetNodeChildren(p_nodes[i],node_children);
        if(result < 1)
        {
            return -1;
        }

        std::copy( node_children.begin(), node_children.end(), std::inserter( children_set, children_set.end() ) );
    }

    std::copy(children_set.begin(), children_set.end(), std::back_inserter(po_children));

    return 1;
}

int ClCedrusLibani::GetNodeParents(Mori::NODE_ID p_node_id, std::vector<Mori::NODE_ID>& po_parents)
{
    if(!this->m_flag_is_usable)
    {
        return -1;
    }

    Mori::ClNode child_node;
    void* child_node_pointer = &child_node;
    Komu::KOMU_UNSIGNED_INT written_bytes = 0;
    
    //Load the ClNode's content
    int result = this->m_komu_instance->GetVirtualBufferData(p_node_id,child_node_pointer,sizeof(child_node),written_bytes);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::GetNodeParents] GetVirtualBufferData returned : " << result << std::endl;
        return -2;
    }   

    if(child_node.m_number_of_parents == 0)
    {
        //std::cout << "[ClCedrusLibani::GetNodeParents] No parents detected for node id " << p_node_id << std::endl;
        return 1;
    }

    Mori::CEDRUS_LIBANI_UNSIGNED_INT new_parents_buffer_size = sizeof(Mori::ClNodeLink)*child_node.m_number_of_parents;

    //UNIQUE_PTR class will free our newly allocated buffer once it's destroyed
    std::unique_ptr<Komu::KOMU_BYTE[]> parents_buffer_manager(new Komu::KOMU_BYTE[new_parents_buffer_size]);

    Komu::KOMU_BYTE* new_parents_buffer = parents_buffer_manager.get();
    void* new_parents_buffer_pointer = (void*)new_parents_buffer;

    result = this->m_komu_instance->GetVirtualBufferData(child_node.m_parents_virtual_buffer_id,new_parents_buffer_pointer,new_parents_buffer_size,written_bytes);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::GetNodeParents] GetVirtualBufferData returned : " << result << std::endl;
        return -3;
    }  

    if(written_bytes == 0)
    {
        return -4;
    }

    Mori::ClNodeLink* all_parents = (Mori::ClNodeLink*)new_parents_buffer;
    for(Mori::CEDRUS_LIBANI_UNSIGNED_INT i=0;i<child_node.m_number_of_parents;i++)
    {
        Mori::ClNodeLink* current_parent = all_parents + i;
        po_parents.push_back(current_parent->p_parent_node_id);
    }

    return 1;
}

int ClCedrusLibani::AddParentToNode(Mori::NODE_ID p_node_id_to_add_parent_to, Mori::NODE_ID p_parent_node_id_to_add, NODE_LINK_TYPE p_link_type)
{
    if(!this->m_flag_is_usable)
    {
        return -1;
    }

    if(p_node_id_to_add_parent_to == this->m_first_node)
    {
        return -2;
    }   

    Mori::ClNode child_node;
    void* child_node_pointer = &child_node;
    Komu::KOMU_UNSIGNED_INT written_bytes = 0;


    int result = this->m_komu_instance->GetVirtualBufferData(p_node_id_to_add_parent_to,child_node_pointer,sizeof(child_node),written_bytes);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::AddParentToNode] GetVirtualBufferData returned : " << result << std::endl;
        return -3;
    }


    if(written_bytes != sizeof(child_node))
    {
        std::cout << "Wrote " << written_bytes << " instead of " << sizeof(child_node) << std::endl;
        return -4;
    }
    
    Mori::CEDRUS_LIBANI_UNSIGNED_INT new_parent_buffer_size = sizeof(Mori::ClNodeLink)*(child_node.m_number_of_parents+1);
        
    
    //UNIQUE_PTR class will free our newly allocated buffer once it's destroyed
    std::unique_ptr<Komu::KOMU_BYTE[]> parent_buffer_manager(new Komu::KOMU_BYTE[new_parent_buffer_size]);

    Komu::KOMU_BYTE* new_parent_buffer = parent_buffer_manager.get();
    void* new_parent_buffer_pointer = (void*)new_parent_buffer;
    
    if(child_node.m_number_of_parents > 0)
    {
        result = this->m_komu_instance->GetVirtualBufferData(child_node.m_parents_virtual_buffer_id,new_parent_buffer_pointer,new_parent_buffer_size,written_bytes);
        if(result < 1)
        {
            std::cout << "[ClCedrusLibani::AddParentToNode] GetVirtualBufferData returned : " << result << std::endl;
            return -5;
        }  

        if(written_bytes != sizeof(Mori::ClNodeLink)*child_node.m_number_of_parents)
        {
            std::cout << "[AddParentToNode][" << child_node.m_number_of_parents << " Parent(s)] I have received " << written_bytes << " bytes for VBID " << child_node.m_parents_virtual_buffer_id << " of size ["<< this->m_komu_instance->m_virtual_address_table->m_data_block_instances[child_node.m_parents_virtual_buffer_id].m_allocated_size_in_data_table <<"], , but i was expecting " << sizeof(Mori::ClNodeLink)*child_node.m_number_of_parents << std::endl;
            std::exit(0);
            return -6;
        }
    }

    Mori::ClNodeLink* child_node_parents_link = (Mori::ClNodeLink*)new_parent_buffer;

    //Maybe the parent is already present and the programmer is just drunk...
    for(Mori::CEDRUS_LIBANI_UNSIGNED_INT i=0;i<child_node.m_number_of_parents;i++)
    {
        if(child_node_parents_link->p_parent_node_id == p_parent_node_id_to_add)
        {
            //std::cout << "Node " << p_parent_node_id_to_add << " is already a parent of " << p_node_id_to_add_parent_to << ", returning..." << std::endl;
            return 1;
        }
    }

    child_node_parents_link = (Mori::ClNodeLink*)new_parent_buffer;
    child_node_parents_link += child_node.m_number_of_parents;
    child_node_parents_link->p_parent_node_id = p_parent_node_id_to_add;
    child_node_parents_link->p_child_node_id = p_node_id_to_add_parent_to;
    child_node_parents_link->m_link_type = p_link_type;    

    child_node.m_number_of_parents++;

    //Save the new parent
    result = this->m_komu_instance->SetVirtualBufferData(child_node.m_parents_virtual_buffer_id,new_parent_buffer,new_parent_buffer_size, this->m_internal_buffer_data_table_ids);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::AddParentToNode] SetVirtualBufferData returned : " << result << std::endl;
        return -7;
    }

    //Save our child node
    result = this->m_komu_instance->SetVirtualBufferData(p_node_id_to_add_parent_to,child_node_pointer,sizeof(child_node), this->m_internal_buffer_data_table_ids);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::AddParentToNode] SetVirtualBufferData returned : " << result << std::endl;
        return -8;
    }    
 

    return 1;

}

int ClCedrusLibani::AddChildToNode(Mori::NODE_ID p_parent_node_id, Mori::NODE_ID p_child_node_id, NODE_LINK_TYPE p_link_type)
{
    if(!this->m_flag_is_usable)
    {
        return -1;
    }

    if(p_parent_node_id == this->m_last_node)
    {
        return -2;
    }           

    Mori::ClNode parent_node;
    void* parent_node_pointer = &parent_node;
    Komu::KOMU_UNSIGNED_INT written_bytes = 0;


    int result = this->m_komu_instance->GetVirtualBufferData(p_parent_node_id,parent_node_pointer,sizeof(parent_node),written_bytes);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::AddChildToNode] GetVirtualBufferData returned : " << result << std::endl;
        return -3;
    }

    if(written_bytes < sizeof(parent_node))
    {
        return -4;
    }

    Mori::CEDRUS_LIBANI_UNSIGNED_INT new_children_buffer_size = sizeof(Mori::ClNodeLink)*(parent_node.m_number_of_children+1);


    //UNIQUE_PTR class will free our newly allocated buffer once it's destroyed
    std::unique_ptr<Komu::KOMU_BYTE[]> children_buffer_manager(new Komu::KOMU_BYTE[new_children_buffer_size]);

    Komu::KOMU_BYTE* new_children_buffer = children_buffer_manager.get();
    void* new_children_buffer_pointer = (void*)new_children_buffer;
    
    if(parent_node.m_number_of_children > 0)
    {
        result = this->m_komu_instance->GetVirtualBufferData(parent_node.m_children_virtual_buffer_id,new_children_buffer_pointer,new_children_buffer_size,written_bytes);
        if(result < 1)
        {
            std::cout << "[ClCedrusLibani::AddChildToNode] GetVirtualBufferData returned : " << result << std::endl;
            return -5;
        }  

        if(written_bytes == 0)
        {
            return -6;
        }
    }
  
    Mori::ClNodeLink* current_child = (Mori::ClNodeLink*)new_children_buffer;
    current_child += parent_node.m_number_of_children;
    current_child->p_parent_node_id = p_parent_node_id;
    current_child->p_child_node_id = p_child_node_id;
    current_child->m_link_type = p_link_type;

    parent_node.m_number_of_children++;

    //Save the new child
    result = this->m_komu_instance->SetVirtualBufferData(parent_node.m_children_virtual_buffer_id,new_children_buffer,new_children_buffer_size, this->m_internal_buffer_data_table_ids);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::AddChildToNode] SetVirtualBufferData 0x1 returned : " << result << std::endl;
        return -7;
    }

    //Save our parent
    result = this->m_komu_instance->SetVirtualBufferData(p_parent_node_id,parent_node_pointer,sizeof(parent_node), this->m_internal_buffer_data_table_ids);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::AddChildToNode] SetVirtualBufferData 0x2 returned : " << result << std::endl;
        return -8;
    }  

    return 1;
}


int ClCedrusLibani::RemoveChildFromNode(Mori::NODE_ID p_parent_node_id, Mori::NODE_ID p_child_node_id)
{
    if(!this->m_flag_is_usable)
    {
        return -1;
    }

    Mori::ClNode parent_node;
    void* parent_node_pointer = &parent_node;
    Komu::KOMU_UNSIGNED_INT written_bytes = 0;
    
    int result = this->m_komu_instance->GetVirtualBufferData(p_parent_node_id,parent_node_pointer,sizeof(parent_node),written_bytes);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::RemoveChildFromNode] GetVirtualBufferData returned : " << result << std::endl;
        return -2;
    }

    if(written_bytes != sizeof(parent_node))
    {
        return -3;
    }

    if(parent_node.m_number_of_children == 0)
    {
        return -4;
    }

    Mori::CEDRUS_LIBANI_UNSIGNED_INT children_buffer_size = sizeof(Mori::ClNodeLink)*parent_node.m_number_of_children;
    
    //UNIQUE_PTR class will free our newly allocated buffer once it's destroyed
    std::unique_ptr<Komu::KOMU_BYTE[]> children_buffer_manager(new Komu::KOMU_BYTE[children_buffer_size]);

    Komu::KOMU_BYTE* children_buffer = children_buffer_manager.get();
    void* children_buffer_pointer = (void*)children_buffer;
 
    result = this->m_komu_instance->GetVirtualBufferData(parent_node.m_children_virtual_buffer_id,children_buffer_pointer,children_buffer_size,written_bytes);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::RemoveChildFromNode] GetVirtualBufferData returned : " << result << std::endl;
        return -5;
    }  

    if(written_bytes != sizeof(Mori::ClNodeLink)*parent_node.m_number_of_children)
    {
        return -6;
    }
  
    Mori::ClNodeLink* current_child = (Mori::ClNodeLink*)children_buffer;
    bool flag_found_child = false;
    for(Mori::CEDRUS_LIBANI_UNSIGNED_INT i=0;i<parent_node.m_number_of_children;i++)
    {
        if(current_child->p_child_node_id == p_child_node_id)
        {
            flag_found_child = true;
            break;
        }

        current_child++;
    }

    if(!flag_found_child)
    {
        return -7;
    }

	if (parent_node.m_number_of_children > 1)
	{
		Mori::CEDRUS_LIBANI_UNSIGNED_INT new_children_buffer_size = sizeof(Mori::ClNodeLink)*(parent_node.m_number_of_children-1);

		//UNIQUE_PTR class will free our newly allocated buffer once it's destroyed
		std::unique_ptr<Komu::KOMU_BYTE[]> new_children_buffer_manager(new Komu::KOMU_BYTE[new_children_buffer_size]);

		Komu::KOMU_BYTE* new_children_buffer = new_children_buffer_manager.get();

		Mori::ClNodeLink* current_child_from_old_buffer = (Mori::ClNodeLink*)children_buffer;
		Mori::ClNodeLink* current_child_from_new_buffer = (Mori::ClNodeLink*)new_children_buffer;
		for (Mori::CEDRUS_LIBANI_UNSIGNED_INT i = 0; i < parent_node.m_number_of_children; i++)
		{
			if (current_child_from_old_buffer->p_child_node_id == p_child_node_id)
			{
				current_child_from_old_buffer++;
				continue;
			}


			std::memcpy(current_child_from_new_buffer, current_child_from_old_buffer, sizeof(Mori::ClNodeLink));
			current_child_from_new_buffer++;
			current_child_from_old_buffer++;
		}


		//Save the new child
		result = this->m_komu_instance->SetVirtualBufferData(parent_node.m_children_virtual_buffer_id, new_children_buffer, new_children_buffer_size, this->m_internal_buffer_data_table_ids);
		if (result < 1)
		{
			std::cout << "[ClCedrusLibani::RemoveChildFromNode] SetVirtualBufferData returned : " << result << std::endl;
			return -8;
		}
	}

	parent_node.m_number_of_children--;


	//Save our parent
    result = this->m_komu_instance->SetVirtualBufferData(p_parent_node_id,parent_node_pointer,sizeof(parent_node), this->m_internal_buffer_data_table_ids);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::RemoveChildFromNode] SetVirtualBufferData returned : " << result << std::endl;
        return -9;
    }     

 
    return 1;
}


int ClCedrusLibani::RemoveParentFromNode(Mori::NODE_ID p_node_id, Mori::NODE_ID p_parent_node_id_to_remove)
{
    if(!this->m_flag_is_usable)
    {
        return -1;
    }

    Mori::ClNode child_node;
    void* child_node_pointer = &child_node;
    Komu::KOMU_UNSIGNED_INT written_bytes = 0;
    
    int result = this->m_komu_instance->GetVirtualBufferData(p_node_id,child_node_pointer,sizeof(child_node),written_bytes);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::RemoveParentFromNode] GetVirtualBufferData returned : " << result << std::endl;
        return -2;
    }

    if(written_bytes < sizeof(child_node))
    {
        return -3;
    }

    if(child_node.m_number_of_parents == 0)
    {
        return -4;
    }

    Mori::CEDRUS_LIBANI_UNSIGNED_INT parents_buffer_size = sizeof(Mori::ClNodeLink)*child_node.m_number_of_parents;
    
    //UNIQUE_PTR class will free our newly allocated buffer once it's destroyed
    std::unique_ptr<Komu::KOMU_BYTE[]> parents_buffer_manager(new Komu::KOMU_BYTE[parents_buffer_size]);

    Komu::KOMU_BYTE* parents_buffer = parents_buffer_manager.get();
    void* parents_buffer_pointer = (void*)parents_buffer;
 
    result = this->m_komu_instance->GetVirtualBufferData(child_node.m_parents_virtual_buffer_id,parents_buffer_pointer,parents_buffer_size,written_bytes);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::RemoveParentFromNode] GetVirtualBufferData returned : " << result << std::endl;
        return -5;
    }  

    if(written_bytes != sizeof(Mori::ClNodeLink)*child_node.m_number_of_parents)
    {
        return -6;
    }
  
    Mori::ClNodeLink* current_parent = (Mori::ClNodeLink*)parents_buffer;
    bool flag_found_parent = false;
    for(Mori::CEDRUS_LIBANI_UNSIGNED_INT i=0;i<child_node.m_number_of_parents;i++)
    {
        if(current_parent->p_parent_node_id == p_parent_node_id_to_remove)
        {
            flag_found_parent = true;
            break;
        }
        current_parent++;
    }

    if(!flag_found_parent)
    {
        return -7;
    }

    Mori::CEDRUS_LIBANI_UNSIGNED_INT new_parents_buffer_size = sizeof(Mori::ClNodeLink)*(child_node.m_number_of_parents-1);
    if(new_parents_buffer_size == 0)
    {
        new_parents_buffer_size = 1;
    }
    
    //UNIQUE_PTR class will free our newly allocated buffer once it's destroyed
    std::unique_ptr<Komu::KOMU_BYTE[]> new_parents_buffer_manager(new Komu::KOMU_BYTE[new_parents_buffer_size]);
    std::memset(new_parents_buffer_manager.get(),0,sizeof(Komu::KOMU_BYTE)*new_parents_buffer_size);
    
    Komu::KOMU_BYTE* new_parents_buffer = new_parents_buffer_manager.get();

    Mori::ClNodeLink* current_parent_from_old_buffer = (Mori::ClNodeLink*)parents_buffer;
    Mori::ClNodeLink* current_parent_from_new_buffer = (Mori::ClNodeLink*)new_parents_buffer;
    for(Mori::CEDRUS_LIBANI_UNSIGNED_INT i=0;i<child_node.m_number_of_parents;i++)
    {
        if(current_parent_from_old_buffer->p_parent_node_id == p_parent_node_id_to_remove)
        {
            current_parent_from_old_buffer++;
            continue;
        }


        std::memcpy(current_parent_from_new_buffer,current_parent_from_old_buffer,sizeof(Mori::ClNodeLink));
        current_parent_from_new_buffer++;
        current_parent_from_old_buffer++;
    }


    //Save the new parents array
    result = this->m_komu_instance->SetVirtualBufferData(child_node.m_parents_virtual_buffer_id,new_parents_buffer,new_parents_buffer_size, this->m_internal_buffer_data_table_ids);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::RemoveParentFromNode] [0x1] SetVirtualBufferData returned : " << result << std::endl;
        return -8;
    }
    
 
    child_node.m_number_of_parents--;

    //Save our child node
    result = this->m_komu_instance->SetVirtualBufferData(p_node_id,child_node_pointer,sizeof(child_node), this->m_internal_buffer_data_table_ids);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::RemoveParentFromNode] [0x2] SetVirtualBufferData returned : " << result << std::endl;
        return -9;
    }     

    return 1;
}


int ClCedrusLibani::DoesParentHasChildNode(Mori::NODE_ID p_parent_node_id, Mori::NODE_ID p_child_node_id)
{
    std::vector<Mori::NODE_ID> children;
    int result = this->GetNodeChildren(p_parent_node_id,children);
    if(result < 1)
    {
        return -1;
    }

    if(std::find(children.begin(), children.end(), p_child_node_id) != children.end())
    {
        return 1;
    }

    return 0;
}

int ClCedrusLibani::DoesChildHasParentNode(Mori::NODE_ID p_child_node_id, Mori::NODE_ID p_parent_node_id)
{
    std::vector<Mori::NODE_ID> parents;
    int result = this->GetNodeParents(p_child_node_id,parents);
    if(result < 1)
    {
        return -1;
    }

    if(std::find(parents.begin(), parents.end(), p_parent_node_id) != parents.end())
    {
        return 1;
    }

    return 0;
}


int ClCedrusLibani::AddBidirectionalRelationshipBetween2Nodes(Mori::NODE_ID p_parent_node, Mori::NODE_ID p_child_node, NODE_LINK_TYPE p_link_type)
{
    if(!this->m_flag_is_usable)
    {
        return -1;
    }

    int result = 0;
    
    if(this->DoesParentHasChildNode(p_parent_node,p_child_node) == 0)
    {
        result = this->AddChildToNode(p_parent_node,p_child_node,p_link_type);
        if(result < 1)
        {
            return -2;
        } 
    }

    if(this->DoesChildHasParentNode(p_child_node, p_parent_node) == 0)
    {
        result = this->AddParentToNode(p_child_node, p_parent_node,p_link_type);
        if(result < 1)
        {
            return -3;
        }        
    }    

    if(p_parent_node != this->m_first_node)
    {
        if(this->DoesChildHasParentNode(p_child_node, this->m_first_node) == 1)
        {    
            result = this->RemoveRelationshipToFirstNode(p_child_node);
            if(result < 1)
            {
                return -4;
            }              
        }    
    }

    if(p_child_node != this->m_last_node)
    {
        if(this->DoesParentHasChildNode(p_parent_node, this->m_last_node) == 1)
        {
            result = this->RemoveRelationshipToLastNode(p_parent_node);
            if(result < 1)
            {
                return -5;
            }                 
        }        
    }

    return 1;
}


int ClCedrusLibani::RemoveBidirectionalRelationshipBetween2Nodes(Mori::NODE_ID p_parent_node, Mori::NODE_ID p_child_node)
{
    if(!this->m_flag_is_usable)
    {
        return -1;
    }

    int result = this->RemoveChildFromNode(p_parent_node,p_child_node);
    if(result < 1)
    {
        return -2;
    }    

    result = this->RemoveParentFromNode(p_child_node, p_parent_node);
    if(result < 1)
    {
        return -3;
    }

    std::vector<Mori::NODE_ID> children, parents;

    result = this->GetNodeChildren(p_parent_node, children);
    if(result < 1)
    {
        return -4;
    }

    result = this->GetNodeParents(p_child_node, parents);     
    if(result < 1)
    {
        return -5;
    }

    if(p_parent_node != this->m_first_node)
    {
        std::vector<Mori::NODE_ID> parents;

        result = this->GetNodeParents(p_child_node, parents);     
        if(result < 1)
        {
            return -6;
        }

        if(parents.size()==0)
        {
            //First node will alway welcome you back
            result = this->AddRelationshipToFirstNode(p_child_node);
            if(result < 1)
            {
                return -7;
            }  
        }
    }

    if(p_child_node != this->m_last_node)
    {
        std::vector<Mori::NODE_ID> children;

        result = this->GetNodeChildren(p_parent_node, children);     
        if(result < 1)
        {
            return -8;
        }

        if(children.size()==0)
        {
            //Last node always want to get adopted
            result = this->AddRelationshipToLastNode(p_parent_node);
            if(result < 1)
            {
                return -9;
            }  
        }

    }
   

    return 1;
}

int ClCedrusLibani::SetNodeData(Mori::NODE_ID p_node_id, void* p_data, Mori::CEDRUS_LIBANI_UNSIGNED_INT p_data_size)
{
    if(!this->m_flag_is_usable)
    {
        return -1;
    }

    if(p_data_size == 0)
    {
        return -2;
    }

    Mori::ClNode node_instance;
    void* node_instance_pointer = &node_instance;
    Komu::KOMU_UNSIGNED_INT written_bytes = 0;
    
    int result = this->m_komu_instance->GetVirtualBufferData(p_node_id,node_instance_pointer,sizeof(node_instance),written_bytes);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::SetNodeData] GetVirtualBufferData returned : " << result << std::endl;
        return -3;
    }

    if(written_bytes != sizeof(node_instance))
    {
        return -4;
    }

    result = this->m_komu_instance->SetVirtualBufferData(node_instance.m_value_virtual_buffer_id,p_data,p_data_size, this->m_node_values_data_table_ids);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::SetNodeData] SetVirtualBufferData returned : " << result << std::endl;
        return -5;
    }    

    return 1;
}

int ClCedrusLibani::GetNodeData(Mori::NODE_ID p_node_id, void* po_data, Mori::CEDRUS_LIBANI_UNSIGNED_INT p_data_size, Mori::CEDRUS_LIBANI_UNSIGNED_INT& po_written_data_size)
{
    if(!this->m_flag_is_usable)
    {
        return -1;
    }


    Mori::ClNode node_instance;
    void* node_instance_pointer = &node_instance;
    Komu::KOMU_UNSIGNED_INT written_bytes = 0;
    
    int result = this->m_komu_instance->GetVirtualBufferData(p_node_id,node_instance_pointer,sizeof(node_instance),written_bytes);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::GetNodeData] GetVirtualBufferData returned : " << result << std::endl;
        return -2;
    }

    if(written_bytes != sizeof(node_instance))
    {
        return -3;
    }

    result = this->m_komu_instance->GetVirtualBufferData(node_instance.m_value_virtual_buffer_id,po_data,p_data_size,po_written_data_size);
    if(result < 1)
    {
        std::cout << "[ClCedrusLibani::GetNodeData] GetVirtualBufferData returned : " << result << std::endl;
        return -4;
    }      

    return 1;
}
