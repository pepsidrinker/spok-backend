#include "ClCedrusLibaniSearchManager.hpp"


using namespace Mori;

ClCedrusLibaniSearchManager::ClCedrusLibaniSearchManager(std::vector< std::shared_ptr<Mori::ClCedrusLibani> >& p_tree_instances, std::shared_ptr<std::mutex> p_search_contexts_stack_mutex, std::shared_ptr<std::mutex> p_class_structure_mutex)
{
    this->m_flag_is_usable = false;

    std::lock_guard<std::mutex> stack_lock(*p_search_contexts_stack_mutex);
    std::lock_guard<std::mutex> structure_lock(*p_class_structure_mutex);    

    this->m_tree_instances = p_tree_instances;
    this->m_search_contexts_stack_mutex = p_search_contexts_stack_mutex;
    this->m_structure_mutex = p_class_structure_mutex;    
    this->m_flag_is_usable = true;
}

ClCedrusLibaniSearchManager::~ClCedrusLibaniSearchManager()
{
    std::lock_guard<std::mutex> stack_lock(*this->m_search_contexts_stack_mutex);
    std::lock_guard<std::mutex> structure_lock(*this->m_structure_mutex);  

    this->m_flag_is_usable = false;
    this->m_tree_instances.clear();
    this->m_search_contexts_stack.clear();
    this->m_flag_is_usable = false;    
}

/*
int ClCedrusLibaniSearchManager::SetWorkingTreeInstance(Mori::ClCedrusLibani& p_tree_instance)
{
    if(!this->m_flag_is_usable)
    {
        return -1;
    }

    std::lock_guard<std::mutex> structure_lock(*this->m_structure_mutex);  
    this->m_tree_instance = &p_tree_instance;

    return 1;
}
*/

int ClCedrusLibaniSearchManager::EnqueueSearchInStack(Mori::ClCedrusLibaniSearch& p_search_context)
{
    if(!this->m_flag_is_usable)
    {
        return -1;
    }

    std::lock_guard<std::mutex> stack_lock(*this->m_search_contexts_stack_mutex);
    this->m_search_contexts_stack.push_back(&p_search_context);
    return 1;
}    


int ClCedrusLibaniSearchManager::RunSearches()
{
    if(!this->m_flag_is_usable)
    {
        return -1;
    }

    std::lock_guard<std::mutex> stack_lock(*this->m_search_contexts_stack_mutex);
    std::lock_guard<std::mutex> structure_lock(*this->m_structure_mutex);
    

    for(Mori::CEDRUS_LIBANI_UNSIGNED_INT i=0;i<this->m_search_contexts_stack.size();i++)
    {

        this->m_search_contexts_stack[i]->m_tree_instances = this->m_tree_instances;
        
        if(this->m_search_contexts_stack[i]->m_pre_search_function_hook != nullptr)
        {
            if(this->m_search_contexts_stack[i]->m_pre_search_function_hook(*this->m_search_contexts_stack[i]) < 1)
            {
                return -1;
            }
        }

        if(this->m_search_contexts_stack[i]->m_search_function_hook != nullptr)
        {
            if(this->m_search_contexts_stack[i]->m_search_function_hook(*this->m_search_contexts_stack[i]) < 1)
            {
                return -2;
            }
        } 

        if(this->m_search_contexts_stack[i]->m_post_search_function_hook != nullptr)
        {
            if(this->m_search_contexts_stack[i]->m_post_search_function_hook(*this->m_search_contexts_stack[i]) < 1)
            {
                return -3;
            }
        }                

    }

    this->m_search_contexts_stack.clear();

    return 1;

}