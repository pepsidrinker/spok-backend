#pragma once

#include "Globals.hpp"

namespace Mori
{
    class ClNode
    {
        public:
        //CEDRUS_LIBANI_UNSIGNED_INT m_idx;
        Komu::KOMU_UNSIGNED_INT m_value_virtual_buffer_id;

        Mori::CEDRUS_LIBANI_UNSIGNED_INT m_number_of_children;
        Mori::CEDRUS_LIBANI_UNSIGNED_INT m_number_of_parents;
    
        //Will each hold an array of ClChild | ClParent
        Komu::KOMU_UNSIGNED_INT m_children_virtual_buffer_id;
        Komu::KOMU_UNSIGNED_INT m_parents_virtual_buffer_id;
    };
}

