#include "ClCedrusLibaniTopologicIterator.hpp"

namespace Mori
{
    ClCedrusLibaniTopologicIterator::ClCedrusLibaniTopologicIterator()
    {
        this->m_tree = nullptr;
        this->m_current_node = 0;
        this->m_traversal_complete = false;
    }

    ClCedrusLibaniTopologicIterator::~ClCedrusLibaniTopologicIterator()
    {

    }

    int ClCedrusLibaniTopologicIterator::Initialize(ClCedrusLibani& p_tree)
    {
        this->m_tree = &p_tree;
        this->m_current_node = p_tree.GetFirstNode();

        return 1;
    }   

    NODE_ID ClCedrusLibaniTopologicIterator::Current()
    {
        return this->m_current_node;
    }
}


