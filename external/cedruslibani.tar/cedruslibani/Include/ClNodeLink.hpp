#pragma once
#include "Globals.hpp"

namespace Mori
{
    class ClNodeLink
    {
        public:
        Komu::KOMU_UNSIGNED_INT p_parent_node_id;
        Komu::KOMU_UNSIGNED_INT p_child_node_id;
        Mori::CEDRUS_LIBANI_NODE_LINK_TYPE m_link_type;
    };
}