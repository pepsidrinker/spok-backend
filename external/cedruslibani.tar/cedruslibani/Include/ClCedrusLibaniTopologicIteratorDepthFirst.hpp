#pragma once

/*
    Beware :
    - This iterator works only for child having only 1 parent : multiple parent is NOT supported. 
      That means the Previous() operator will NOT work if the current node is the Last Node of the tree.
 */

#include "ClCedrusLibaniTopologicIterator.hpp"
#include <vector>
#include <stack>
#include <set>
#include <deque>

namespace Mori
{
    class ClCedrusLibaniTopologicIteratorDepthFirst : public ClCedrusLibaniTopologicIterator
    {
        private:
            std::set<Mori::NODE_ID> m_already_visited_nodes;
            std::vector<Mori::NODE_ID> m_route_stack;
            std::deque<Mori::NODE_ID> m_route_history;
        public:
            ClCedrusLibaniTopologicIteratorDepthFirst();
            ~ClCedrusLibaniTopologicIteratorDepthFirst();

            virtual int Initialize(ClCedrusLibani& p_tree);
            virtual int Reset();
            virtual int Previous();
            virtual int Next();
    };
}


