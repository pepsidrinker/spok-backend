#pragma once

#include "ClCedrusLibani.hpp"
#include "ClCedrusLibaniSearch.hpp"

#include <deque>
#include <mutex>

namespace Mori
{
    class ClCedrusLibaniSearchManager
    {
        protected:
            bool m_flag_is_usable;
            std::vector< std::shared_ptr<Mori::ClCedrusLibani> > m_tree_instances;
            std::deque<Mori::ClCedrusLibaniSearch*> m_search_contexts_stack;
            std::shared_ptr<std::mutex> m_search_contexts_stack_mutex;
            std::shared_ptr<std::mutex> m_structure_mutex;


        public:
            ClCedrusLibaniSearchManager(std::vector< std::shared_ptr<Mori::ClCedrusLibani> >& p_tree_instances, std::shared_ptr<std::mutex> p_search_contexts_stack_mutex, std::shared_ptr<std::mutex> p_class_structure_mutex);
            ~ClCedrusLibaniSearchManager();
            //int SetWorkingTreeInstance(Mori::ClCedrusLibani& p_tree_instance);
            int EnqueueSearchInStack(Mori::ClCedrusLibaniSearch& p_search_context);       
            int RunSearches(); 
    };
}