#pragma once

#include "ClCedrusLibani.hpp"

namespace Mori
{
    class ClCedrusLibaniTopologicIterator
    {
        protected:
            ClCedrusLibani* m_tree;
            NODE_ID m_current_node;
            bool m_traversal_complete;

        public:
            ClCedrusLibaniTopologicIterator();
            ~ClCedrusLibaniTopologicIterator();

            virtual int Initialize(ClCedrusLibani& p_tree);
            virtual int Reset() = 0;
            virtual NODE_ID Current();
            virtual int Previous() = 0;
            virtual int Next() = 0;
    };
}


