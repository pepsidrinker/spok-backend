#pragma once

#include <komu/ClKomu.hpp>

#include "Globals.hpp"
#include "ClNode.hpp"
#include "ClNodeLink.hpp"

#include <vector>
#include <unordered_set>
#include <memory>
#include <list>


//For debugging purpose
#include <iostream>

namespace Mori
{
    class ClCedrusLibani
    {
        private:
            std::shared_ptr<Komu::ClKomu> m_komu_instance;

            Mori::NODE_ID m_first_node;
            Mori::NODE_ID m_last_node;
            
            CEDRUS_LIBANI_FEATURE_FLAGS m_enabled_features;

            std::vector< Komu::KOMU_UNSIGNED_INT > m_internal_buffer_data_table_ids;
            std::vector< Komu::KOMU_UNSIGNED_INT > m_node_values_data_table_ids;

            bool m_flag_is_usable;

            int RemoveRelationshipToFirstNode(Mori::NODE_ID p_node_id);
            int RemoveRelationshipToLastNode(Mori::NODE_ID p_node_id);
            int AddRelationshipToFirstNode(Mori::NODE_ID p_node_id);
            int AddRelationshipToLastNode(Mori::NODE_ID p_node_id);

            int AddChildToNode(Mori::NODE_ID p_parent_node_id, Mori::NODE_ID p_child_node, NODE_LINK_TYPE p_link_type);
            int AddParentToNode(Mori::NODE_ID p_child_node_id, Mori::NODE_ID p_parent_node_id, NODE_LINK_TYPE p_link_type);
           
            int RemoveChildFromNode(Mori::NODE_ID p_parent_node_id, Mori::NODE_ID p_child_node_id);
            int RemoveParentFromNode(Mori::NODE_ID p_parent_node_id, Mori::NODE_ID p_child_node_id); 

            /*
               < 0 : Error
               0 : Does not have child
               1 : Has child
            */
            int DoesParentHasChildNode(Mori::NODE_ID p_parent_node_id, Mori::NODE_ID p_child_node_id); 
            int DoesChildHasParentNode(Mori::NODE_ID p_child_node_id, Mori::NODE_ID p_parent_node_id);        

        public:

            /*
                All parameters of the constructor are sizes related to the tree's node's VALUE buffer :
                Relationship buffers will be handled by the tree itself.
            */
            ClCedrusLibani(Mori::CEDRUS_LIBANI_UNSIGNED_INT p_tree_node_values_memory_pool_size, Mori::CEDRUS_LIBANI_UNSIGNED_INT p_number_of_data_tables, Mori::CEDRUS_LIBANI_UNSIGNED_INT p_number_of_virtual_data_block);
            ~ClCedrusLibani();

            bool IsUsable();
            
            int CreateNode(Mori::NODE_ID& po_node_id);
            int DeleteNode(Mori::NODE_ID p_node_id);

            int GetNodeChildren(Mori::NODE_ID p_node_id, std::vector<Mori::NODE_ID>& po_children);
            int GetNodeParents(Mori::NODE_ID p_node_id, std::vector<Mori::NODE_ID>& po_parents);

            int GetNodesChildren(std::vector<Mori::NODE_ID>& p_nodes, std::vector<Mori::NODE_ID>& po_children);

            int AddBidirectionalRelationshipBetween2Nodes(Mori::NODE_ID p_parent_node, Mori::NODE_ID p_child_node, NODE_LINK_TYPE p_link_type);
            int RemoveBidirectionalRelationshipBetween2Nodes(Mori::NODE_ID p_parent_node, Mori::NODE_ID p_child_node);

            int SetNodeData(Mori::NODE_ID p_node_id, void* p_data, Mori::CEDRUS_LIBANI_UNSIGNED_INT p_data_size);
            int GetNodeData(Mori::NODE_ID p_node_id, void* po_data, Mori::CEDRUS_LIBANI_UNSIGNED_INT p_data_size, Mori::CEDRUS_LIBANI_UNSIGNED_INT& po_written_data_size);

            Mori::NODE_ID GetFirstNode();    
            Mori::NODE_ID GetLastNode();  

            std::vector< Komu::KOMU_UNSIGNED_INT > GetDataTableIDsUsedForInternalStorage();  
            std::vector< Komu::KOMU_UNSIGNED_INT > GetDataTableIDsUsedForNodeValueStorage();  
      
            int GetAllNodeIDs(std::vector<Mori::NODE_ID>& p_result);
            std::shared_ptr<Komu::ClKomu> GetUnderlayingMemoryManagerInstance();
    };

    typedef std::shared_ptr<ClCedrusLibani> CEDRUS_LIBANI_POINTER;


}