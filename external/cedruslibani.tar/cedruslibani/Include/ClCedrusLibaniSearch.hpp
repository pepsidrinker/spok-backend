#pragma once

#include "ClCedrusLibani.hpp"
#include <vector>

namespace Mori
{
    struct ClCedrusLibaniSearchArguments
    {
        void* m_argument_buffer;
        Mori::CEDRUS_LIBANI_UNSIGNED_INT m_argument_buffer_size;
    };
    struct ClCedrusLibaniSearch
    {
        std::vector< std::shared_ptr<Mori::ClCedrusLibani> > m_tree_instances;
        int (*m_pre_search_function_hook)(Mori::ClCedrusLibaniSearch& p_context);
        int (*m_search_function_hook)(Mori::ClCedrusLibaniSearch& p_context); 
        int (*m_post_search_function_hook)(Mori::ClCedrusLibaniSearch& p_context);
        std::vector<Mori::ClCedrusLibaniSearchArguments> m_arguments;
        std::vector<Mori::NODE_ID> po_search_resultset;
    };
}
