#pragma once

#include <cstdint>
#include <komu/ClKomu.hpp>

namespace Mori
{
    typedef Komu::KOMU_UNSIGNED_INT NODE_ID;
    typedef Komu::KOMU_UNSIGNED_INT CEDRUS_LIBANI_UNSIGNED_INT;
    typedef Komu::KOMU_UNSIGNED_LONG  CEDRUS_LIBANI_UNSIGNED_LONG;
    typedef std::uint8_t CEDRUS_LIBANI_NODE_LINK_TYPE;
    typedef std::uint64_t CEDRUS_LIBANI_FEATURE_FLAGS;

    enum NODE_LINK_TYPE{NODE_LINK_TYPE_STANDARD = 0, NODE_LINK_TYPE_REFERENCE = 1};
}