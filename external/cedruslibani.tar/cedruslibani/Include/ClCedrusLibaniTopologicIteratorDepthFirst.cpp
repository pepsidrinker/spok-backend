#include "ClCedrusLibaniTopologicIteratorDepthFirst.hpp"

namespace Mori
{
    ClCedrusLibaniTopologicIteratorDepthFirst::ClCedrusLibaniTopologicIteratorDepthFirst()
    {
    }

    ClCedrusLibaniTopologicIteratorDepthFirst::~ClCedrusLibaniTopologicIteratorDepthFirst()
    {
    }  

    int ClCedrusLibaniTopologicIteratorDepthFirst::Initialize(ClCedrusLibani& p_tree)
    {
        if(ClCedrusLibaniTopologicIterator::Initialize(p_tree)!=1)
        {
            return -1;
        }

        if(!this->Reset())
        {
            return -2;
        }
        
        return 1;
    }

    int ClCedrusLibaniTopologicIteratorDepthFirst::Reset()
    {
        this->m_current_node = this->m_tree->GetFirstNode();

        this->m_route_stack = std::vector<Mori::NODE_ID>();
        this->m_route_stack.push_back(this->m_tree->GetFirstNode());

        this->m_already_visited_nodes.clear();
        this->m_already_visited_nodes.insert(this->m_tree->GetFirstNode());

        this->m_route_history.clear();
        this->m_route_history.push_back(this->m_tree->GetFirstNode());

        return 1;
    }      



    int ClCedrusLibaniTopologicIteratorDepthFirst::Previous()
    {
        return -1;    
    }      

    int ClCedrusLibaniTopologicIteratorDepthFirst::Next()
    {
        Mori::NODE_ID node_to_ask_for_children = this->m_current_node;
        bool flag_should_keep_searching = true;
        while(flag_should_keep_searching)
        {
            /* 
            std::cout << "====================== STACK =================" << std::endl;
            std::cout << "[" << std::endl;
            for(std::size_t i=0;i<this->m_route_stack.size();i++)
            {
                std::cout << this->m_route_stack[i] << ", ";
            }
            

            std::cout << "]" << std::endl;
            */
           
            /*
                Do we have children not visited yet ?
            */
            std::vector<Mori::NODE_ID> child_nodes;
            int result = this->m_tree->GetNodeChildren(node_to_ask_for_children,child_nodes);
            if(result != 1)
            {
                return -1;                        
            }    

            if(child_nodes.size()>0)
            {
                for(std::size_t i=0;i<child_nodes.size();i++)
                {
                    const bool is_child_alreay_visited = this->m_already_visited_nodes.find(child_nodes[i]) != this->m_already_visited_nodes.end();

                    if(!is_child_alreay_visited)
                    {
                        this->m_current_node = child_nodes[i];
                        this->m_route_stack.push_back(child_nodes[i]);
                        this->m_already_visited_nodes.insert(child_nodes[i]);
                        this->m_route_history.push_back(child_nodes[i]);
                        return 1;
                    }
                }
            }     

            if(this->m_route_stack.size()==0)
            {
                return -2;
            }


            this->m_route_stack.pop_back();            
            node_to_ask_for_children = this->m_route_stack.back();

            
        }


        return -3;
    }      
}


