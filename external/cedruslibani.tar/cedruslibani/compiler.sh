#!/bin/bash

#rm -f -R *.o
#rm -f a.out
#g++ --std=c++17 -Wall -g -c Include/*.cpp
#g++ --std=c++17 -Wall -g -c main.cpp
#g++ --std=c++17 -Wall -g *.o -o a.out -lmori

echo "Compiling Library ..."
rm *.o
rm *.gch
rm Includes/*.o
rm Includes/*.gch
rm libmori.so*

g++ --std=c++17 -lpthread -lkomu -Wall -g -c -fPIC Include/*.cpp
g++ -shared -Wl,-soname,libmori.so.1 -o libmori.so.1 *.o -lpthread -lkomu

echo "Copying Headers & Library ..."

unlink /usr/lib/libmori.so
rm -f /usr/lib/libmori.so.1
cp libmori.so.1 /usr/lib/libmori.so.1
ln -s /usr/lib/libmori.so.1 /usr/lib/libmori.so 

mkdir -p /usr/include/mori
rm -f -R /usr/include/mori/*
cp -r Include/*.hpp /usr/include/mori/


echo "Compiling main.cpp ..."

rm *.o
rm *.gch
rm Includes/*.o
rm Includes/*.gch
rm a.out

#g++ --std=c++14 -Wall -g -c Includes/*.cpp
g++ --std=c++17 -lpthread  -Wall -g -c main.cpp -lkomu
g++ --std=c++17 -lpthread  -Wall -g *.o -o a.out -lkomu -lmori

echo "Cleaning ..."
rm *.o
rm *.gch
rm Includes/*.o
rm Includes/*.gch


exit 0
