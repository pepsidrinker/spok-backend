/*
#include "Include/Globals.hpp"
#include "Include/ClCedrusLibani.hpp"
#include "Include/ClCedrusLibaniSearchManager.hpp"
*/

#include <mori/ClCedrusLibani.hpp>
#include <mori/ClCedrusLibaniTopologicIteratorDepthFirst.hpp>


#include <iostream>

using namespace Mori;

void PrintNodeRelationship(Mori::NODE_ID p_node, ClCedrusLibani& p_manager)
{
    std::vector<Mori::NODE_ID> parents, children;
    p_manager.GetNodeChildren(p_node, children);
    p_manager.GetNodeParents(p_node, parents);    

    std::cout << "Node [" << p_node <<"] has " << parents.size() << " parents, " << children.size() << " children" << std::endl;
    for(Mori::CEDRUS_LIBANI_UNSIGNED_INT i=0;i<parents.size();i++)
    {
        std::cout << "Parent ID # " << i << " : " << parents[i] << std::endl;
    }
    for(Mori::CEDRUS_LIBANI_UNSIGNED_INT i=0;i<children.size();i++)
    {
        std::cout << "Children ID # " << i << " : " << children[i] << std::endl;
    }    

    std::cout << std::endl << std::endl;
}

void PrintTree(ClCedrusLibani& p_manager)
{
    std::vector<Mori::NODE_ID> nodes;
    p_manager.GetAllNodeIDs(nodes);
    std::cout << "Printing all " << nodes.size() << " notes of the tree" << std::endl;
    for(Mori::CEDRUS_LIBANI_UNSIGNED_INT i=0;i<nodes.size();i++)
    {
        PrintNodeRelationship(nodes[i],p_manager);
    } 
}

int AddNewChild(Mori::NODE_ID p_parent_node, Mori::NODE_ID& po_new_child, ClCedrusLibani& p_manager, std::string p_string)
{
    std::cout << "Entering process of creating a new child" << std::endl;
    Mori::NODE_ID child_node = 0;
    int result = p_manager.CreateNode(child_node);
    if(result < 1)
    {
        std::cout << "Coudl not create child node : " << result << std::endl;
        return -1;
    }

    std::cout << "Child " << child_node << " has just been created" << std::endl;


    result = p_manager.AddBidirectionalRelationshipBetween2Nodes(p_parent_node,child_node, Mori::NODE_LINK_TYPE_STANDARD);
    if(result < 1)
    {
        std::cout << "Coudl not add parent to node : " << result << std::endl;
        return -3;        
    }   



    //Verify that our frienship is not hypocretical
    
    std::vector<Mori::NODE_ID> parents, children;
    p_manager.GetNodeChildren(p_parent_node, children);
    p_manager.GetNodeParents(child_node, parents); 

    if(parents.size()!=1 || parents[0] != p_parent_node)
    {
        std::cout << "Relationship hypocrisy : " << child_node << " should have " << p_parent_node << " as parent" << std::endl;
        std::exit(0);
        return -4;
    }

    /* 
    if(children.size()!=1 || children[0] != child_node)
    {
        std::cout << "Relationship hypocrisy : " << p_parent_node << " should only have " << child_node << " has children . [Parent has " << children.size() << " children]" << std::endl;
        for(Mori::CEDRUS_LIBANI_UNSIGNED_INT i=0;i<children.size();i++)
        {
            std::cout << "Children ID # " << i << " : " << children[i] << std::endl;
        }        
        std::exit(0);
        return -5;
    }  
    */

    std::cout << "Relationship between " << p_parent_node << " and " << child_node << " confirmed" << std::endl;  
    
 

    std::cout << "Parent have been added to child" << std::endl;
    PrintNodeRelationship(child_node, p_manager);

    po_new_child = child_node; 

    /*
    if(child_node == 4987)
    {
        std::cout << "Child_node = 4987, exiting.." << std::endl;
        std::exit(0);
    }
    */

    return 1;  
}

int main()
{
    ClCedrusLibani manager(1024*1024*500, 10, 1024*100);
    if(!manager.IsUsable())
    {
        std::cout << " Could not instanciate tree" << std::endl;
    }

    Mori::NODE_ID root_node = manager.GetFirstNode();
    std::cout << "Root node ID is " << root_node << std::endl;

    Mori::NODE_ID last_node = manager.GetLastNode();
    std::cout << "LAst node ID is " << last_node << std::endl;

    Mori::NODE_ID c1 = 0, c2 = 0, gc1 = 0;
    AddNewChild(root_node,c1,manager,"Child 1");
    AddNewChild(root_node,c2,manager,"Child 2");
    AddNewChild(c1,gc1,manager,"Grand Child 1");
   
    std::cout << "Root node : [" << root_node << "]" << std::endl;
    std::cout << "Child 1 node : [" << c1 << "]" << std::endl;
    std::cout << "Child 2 node : [" << c2 << "]" << std::endl;
    std::cout << "Grand Child 1 node : [" << gc1 << "]" << std::endl;
    std::cout << "Last node : [" << last_node << "]" << std::endl;


    /*
    Mori::NODE_ID node_to_add_child_to = 0;


    Mori::NODE_ID current_parent = root_node;
    for(Mori::CEDRUS_LIBANI_UNSIGNED_INT i=0;i<10;i++)
    {
        std::string text = "Player ";
        text += std::to_string(i);        

        Mori::NODE_ID new_child = 0;

        if(AddNewChild(current_parent,new_child,manager,text) < 1)
        {
            std::cout << "Could not add child " << i << std::endl;
        }

        if(i==5)
        {
            Mori::NODE_ID rien_child = 0;
            if(AddNewChild(current_parent,rien_child,manager,text) < 1)
            {
                std::cout << "Could not add child "  << std::endl;
                return 0;
            }
        }
        //std::cout << "Memory left : " << manager.GetUnderlayingMemoryManagerInstance()->GetAvailableMemory() << " byte(s)" << std::endl;

        current_parent = new_child;
    }
    */


    std::cout << std::endl;
    //PrintTree(manager);


    std::cout << "I will now parse the free DF" << std::endl;
    ClCedrusLibaniTopologicIteratorDepthFirst it;
    it.Initialize(manager);
    unsigned long counter = 0;
    do
    {
        std::cout << " I am at node " << it.Current() << std::endl;
        counter++;   

        if(counter > 40)
        {
            break;
        }     
    }while(it.Next()==1);
    std::cout << "Iterated over " << counter << " items" << std::endl;

    /*
    std::vector<Mori::NODE_ID> all_nodes;
    manager.GetAllNodeIDs(all_nodes);
    std::cout << "All nodes returns " << all_nodes.size() << std::endl;
    for(std::size_t i=0;i<all_nodes.size();i++)
    {
        std::cout << all_nodes[i] << std::endl;
    }
    */

    
    


    return 1;
}
