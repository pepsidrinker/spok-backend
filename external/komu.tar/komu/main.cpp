#include <komu/ClKomu.hpp>
#include <iostream>
#include <cstring>
#include <string>


//4 Debug purpose 
#include <algorithm>
#include <iostream>

std::string CreateRandomString( size_t length )
{
    auto randchar = []() -> char
    {
        const char charset[] =
        "0123456789"
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "abcdefghijklmnopqrstuvwxyz";
        const size_t max_index = (sizeof(charset) - 1);
        return charset[ rand() % max_index ];
    };
    std::string str(length,0);
    std::generate_n( str.begin(), length, randchar );
    return str;
}

int main()
{
    std::shared_ptr<Komu::ClVirtualAddressTable> vt = std::make_shared<Komu::ClVirtualAddressTable>(250);

    std::vector< std::shared_ptr<Komu::ClDataTable> > data_tables;
    
    auto dt1 = std::make_shared<Komu::ClDataTable>();
    if(dt1->Initialize(50) != 1)
    {
        std::cout << "Error intializing dt1" << std::endl;
    }
    data_tables.push_back(dt1);

    auto dt2 = std::make_shared<Komu::ClDataTable>();
    if(dt2->Initialize(2048) != 1)
    {
        std::cout << "Error intializing dt2" << std::endl;
    }
    data_tables.push_back(dt2);    



    


    Komu::ClKomu rien(vt,data_tables);

    std::vector<Komu::KOMU_UNSIGNED_INT> data_table_ids;
    data_table_ids.push_back(0);
    data_table_ids.push_back(1);

     

    std::srand(std::time(nullptr)); // use current time as seed for random generator    
    std::vector<std::string> random_strings;
    std::vector<Komu::KOMU_UNSIGNED_INT> random_buffers;
    int total_memory_used = 0;    
    for(int i=0;i<40;i++)
    {
        std::cout << "Total memory used yet by Komu " << total_memory_used << std::endl;

        int random_size = std::rand()/((RAND_MAX + 1u)/25)+1;       
        std::string random_string = CreateRandomString(random_size);
        random_strings.push_back(random_string);

        Komu::KOMU_UNSIGNED_INT buffer_id = 0;
        std::cout << "Before CVB" << std::endl;
        int result = rien.CreateVirtualBufferFromDataTableGroup(data_table_ids,random_string.size(),buffer_id);
        if(result<1)
        {
            std::cout << "Could not create buffer of length " << random_string.size() << " . Result = " << result << std::endl;
            return 0;
        }
        std::cout << "After CVB" << std::endl;
        total_memory_used += random_string.size();

        random_buffers.push_back(buffer_id);
        result = rien.SetVirtualBufferData(buffer_id,(void*)random_string.c_str(), random_string.size());
        if(result<1)
        {
            std::cout << "Cant write into buffer " << buffer_id << std::endl;
            return 0;
        }   

        std::cout << i << " - Creating random string [" << random_string << "] of size [" << random_size << "] with buffer ID " << buffer_id << " having offset " << vt->m_data_block_instances[buffer_id].m_allocated_buffer_offset_in_data_table << std::endl;
    }  

    //Perfect, let's see if any will be corrupted if we write over them
    std::cout << std::endl << std::endl;
    std::cout << "Step 1 - [1 thread] Consecutive WRITE in the pool" << std::endl;
    for(int i=0;i<40;i++)
    {
        Komu::KOMU_BYTE buffer[100];
        void* voided_buffer = (void*)buffer;
        std::memset(buffer,'\0', 100);
        Komu::KOMU_UNSIGNED_INT buffer_id = random_buffers[i];
        Komu::KOMU_UNSIGNED_INT written_size = 0;
        int result = rien.GetVirtualBufferData(buffer_id,voided_buffer, 100,written_size);
        if(result<1)
        {
            std::cout << "Cant read from buffer " << buffer_id << std::endl;
            return 0;
        }        

        std::string wanted_string = random_strings[i];
        result = std::memcmp(buffer,wanted_string.c_str(),wanted_string.size());  
        
        if(result==0)
        {
            std::cout << "String " << i << " passes the test" << " , @ offset " << vt->m_data_block_instances[random_buffers[i]].m_allocated_buffer_offset_in_data_table << std::endl;
        }
        else
        {
            std::cout << "String " << i << " of size " << wanted_string.size() << " is different : " << wanted_string << " || " << buffer << std::endl;
        }
    }  





for(int p=0;p<50;p++)
{

    for(int i=0;i<40;i++)
    {
        Komu::KOMU_UNSIGNED_INT buffer_id = random_buffers[i];
        /*
        int result = rien.DeleteVirtualBuffer(buffer_id);
        if(result < 1)
        {
            std::cout << "Could not delete virtual buffer #" << buffer_id << std::endl;
            return 0;
        }
        */
        total_memory_used -= random_strings[i].size();

        int random_size = std::rand()/((RAND_MAX + 1u)/25)+1;       
        std::string random_string = CreateRandomString(random_size);
        random_strings[i] = random_string;
        /*
        result = rien.CreateVirtualBuffer(random_string.size(),buffer_id);
        if(result<1)
        {
            std::cout << "Could not create buffer of length " << random_string.size() << " . Result = " << result << std::endl;
            return 0;
        }
        random_buffers[i] = buffer_id;
        */
        total_memory_used += random_string.size();        

        int result = rien.SetVirtualBufferData(buffer_id,(void*)random_string.c_str(), random_string.size());
        if(result<1)
        {
            std::cout << "Can't write into buffer " << buffer_id << "| " << result <<  std::endl;
            return 0;
        }   

        std::cout << i << " - Creating random string [" << random_string << "] of size [" << random_size << "] with buffer ID " << buffer_id << " having offset " << vt->m_data_block_instances[buffer_id].m_allocated_buffer_offset_in_data_table << std::endl;         
    }


    //Perfect, let's see if any have been corrupted
    std::cout << std::endl << std::endl;
    std::cout << "Step " << p << " | 2 - [1 thread] Consecutive DELETE and CREATE in the pool" << std::endl;
    for(int i=0;i<40;i++)
    {
        Komu::KOMU_BYTE buffer[100];
        void* voided_buffer = (void*)buffer;
        std::memset(buffer,'\0', 100);
        Komu::KOMU_UNSIGNED_INT buffer_id = random_buffers[i];
        Komu::KOMU_UNSIGNED_INT written_size = 0;
        int result = rien.GetVirtualBufferData(buffer_id,voided_buffer, 100,written_size);
        if(result<1)
        {
            std::cout << "Cant read from buffer " << buffer_id << std::endl;
            return 0;
        }        
     

        std::string wanted_string = random_strings[i];
        result = std::memcmp(buffer,wanted_string.c_str(),wanted_string.size());  
        
        if(result==0)
        {
            std::cout << "String " << i << " [" << wanted_string << "] of size " << wanted_string.size() <<  " passes the test" << " , @bufferID " << buffer_id << " @ offset " << vt->m_data_block_instances[buffer_id].m_allocated_buffer_offset_in_data_table << std::endl;
        }
        else
        {
            char* buffer_container = new char[wanted_string.size()+1];
            std::memcpy(buffer_container,buffer,wanted_string.size());
            buffer_container[wanted_string.size()] = '\0';
            std::cout << "String " << i << " of size " << wanted_string.size() << " is different : " << wanted_string << " || " << buffer_container << " , @ offset " << vt->m_data_block_instances[random_buffers[i]].m_allocated_buffer_offset_in_data_table << std::endl;
            delete [] buffer_container;
            return 0;
        }
    } 


    std::cout << "Defragmenting" << std::endl;
    if(rien.Defragment()<1)
    {
        std::cout << "Could not defragment" << std::endl;
        return 0;
    }


    //Perfect, let's see if any have been corrupted
    std::cout << std::endl << std::endl;
    std::cout << "Step " << p << " | 2 - [1 thread] After defragmentation of VirtualAddressTable and DataTable" << std::endl;
    for(int i=0;i<40;i++)
    {
        Komu::KOMU_BYTE buffer[100];
        void* voided_buffer = (void*)buffer;
        std::memset(buffer,'\0', 100);
        Komu::KOMU_UNSIGNED_INT buffer_id = random_buffers[i];
        Komu::KOMU_UNSIGNED_INT written_size = 0;
        int result = rien.GetVirtualBufferData(buffer_id,voided_buffer, 100,written_size);
        if(result<1)
        {
            std::cout << "Cant read from buffer " << buffer_id << " Error : " << result << std::endl;
            return 0;
        }        
     

        std::string wanted_string = random_strings[i];
        result = std::memcmp(buffer,wanted_string.c_str(),wanted_string.size());  
        
        if(result==0)
        {
            std::cout << "String " << i << " passes the test" << std::endl;
        }
        else
        {
            char* buffer_container = new char[wanted_string.size()+1];
            std::memcpy(buffer_container,buffer,wanted_string.size());
            buffer_container[wanted_string.size()] = '\0';
            std::cout << "String " << i << " of size " << wanted_string.size() << " is different : " << wanted_string << " || " << buffer_container << " , @ offset " << vt->m_data_block_instances[random_buffers[i]].m_allocated_buffer_offset_in_data_table << std::endl;
            delete [] buffer_container;
            return 0;
        }
    } 

}

std::vector<Komu::KOMU_UNSIGNED_INT> used_block_ids = rien.GetAllAllocatedVirtualBufferIDs();
std::cout << "there is " << used_block_ids.size() << " used block ids - number given by GetAllAllocatedVirtualBufferIDs" << std::endl;

std::cout << " I am saving " << vt->m_data_block_instances.size() << " blocks, of which " << vt->m_available_data_block_ids.size() << " are available" << std::endl;

/*
std::ofstream outfile ("rien.bin",std::ofstream::binary);

if(rien.SavetoFile(outfile) < 1)
{
    std::cout << "Could not save to file" << std::endl;
}



std::ifstream infile ("rien.bin",std::ifstream::binary);

int result = rien.LoadFromFile(infile);
if(result < 1)
{
    std::cout << "Could not load from file : " << result << std::endl;
}
*/

used_block_ids = rien.GetAllAllocatedVirtualBufferIDs();
std::cout << "there is " << used_block_ids.size() << " used block ids - number given by GetAllAllocatedVirtualBufferIDs" << std::endl;

std::cout << " I am saving " << vt->m_data_block_instances.size() << " blocks, of which " << vt->m_available_data_block_ids.size() << " are available" << std::endl;


    std::cout << "Defragmenting" << std::endl;
    if(rien.Defragment()<1)
    {
        std::cout << "Could not defragment" << std::endl;
        return 0;
    }

    if(rien.ShrinkAllocatedMemoryToFit()<1)
    {
        std::cout << "Could not shrink" << std::endl;
        return 0;        
    }


    //Perfect, let's see if any have been corrupted
    std::cout << std::endl << std::endl;
    std::cout << "Step final " << " | 1 - [1 thread] After defragmentation of VirtualAddressTable and DataTable" << std::endl;
    for(int i=0;i<40;i++)
    {
        Komu::KOMU_BYTE buffer[100];
        void* voided_buffer = (void*)buffer;
        std::memset(buffer,'\0', 100);
        Komu::KOMU_UNSIGNED_INT buffer_id = random_buffers[i];
        Komu::KOMU_UNSIGNED_INT written_size = 0;
        int result = rien.GetVirtualBufferData(buffer_id,voided_buffer, 100,written_size);
        if(result<1)
        {
            std::cout << "Cant read from buffer " << buffer_id << " Error : " << result << std::endl;
            return 0;
        }        
     

        std::string wanted_string = random_strings[i];
        result = std::memcmp(buffer,wanted_string.c_str(),wanted_string.size());  
        
        if(result==0)
        {
            std::cout << "String " << i << " passes the test" << std::endl;
        }
        else
        {
            char* buffer_container = new char[wanted_string.size()+1];
            std::memcpy(buffer_container,buffer,wanted_string.size());
            buffer_container[wanted_string.size()] = '\0';
            std::cout << "String " << i << " of size " << wanted_string.size() << " is different : " << wanted_string << " || " << buffer_container << " , @ offset " << vt->m_data_block_instances[random_buffers[i]].m_allocated_buffer_offset_in_data_table << std::endl;
            delete [] buffer_container;
            return 0;
        }
    }



    std::cout << "Available memory size : " <<  rien.GetAvailableMemorySize() << std::endl;
    std::cout << "Unavailable memory size : " <<  rien.GetUnavailableMemorySize() << std::endl;
    std::cout << "Total memory size : " <<  rien.GetTotalAllocatedMemorySize() << std::endl;
}



