#!/bin/bash

echo "Compiling Library ..."

rm *.o
rm *.gch
rm Includes/*.o
rm Includes/*.gch
rm libkomu.so*

g++ --std=c++17 -O3 -lpthread -Wall -g -c -fPIC Includes/*.cpp
g++ -shared -O3 -Wl,-soname,libkomu.so.1 -o libkomu.so.1 *.o -lpthread

echo "Copying Headers & Library ..."

unlink /usr/lib/libkomu.so
rm -f /usr/lib/libkomu.so.1
cp libkomu.so.1 /usr/lib/libkomu.so.1
ln -s /usr/lib/libkomu.so.1 /usr/lib/libkomu.so 

mkdir -p /usr/include/komu
rm -f -R /usr/include/komu/*
cp -r Includes/*.hpp /usr/include/komu/


echo "Compiling main.cpp ..."

rm *.o
rm *.gch
rm Includes/*.o
rm Includes/*.gch
rm a.out

#g++ --std=c++14 -Wall -g -c Includes/*.cpp
g++ --std=c++17 -O3 -lpthread -Wall -g -c main.cpp
g++ --std=c++17 -O3 -lpthread -Wall -g *.o -o a.out -lkomu

echo "Cleaning ..."
rm *.o
rm *.gch
rm Includes/*.o
rm Includes/*.gch

exit 0
