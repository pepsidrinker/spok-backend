#pragma once
#include "Globals.hpp"
#include "ClVirtualDataBlock.hpp"
#include "ClDataTable.hpp"
#include <vector>
#include <limits>
#include <memory>

namespace Komu
{
    class ClVirtualAddressTable
    {  
        public:
            //Contain all the ClVirtualDataBlock in this table
            std::vector<Komu::ClVirtualDataBlock> m_data_block_instances;

            //Re-usable block IDS
            std::vector<Komu::KOMU_UNSIGNED_INT> m_available_data_block_ids; 
            bool m_flag_is_usable;
        

        public:
            ClVirtualAddressTable(Komu::KOMU_UNSIGNED_INT p_number_of_virtual_data_block);
            ~ClVirtualAddressTable();
            int LoadFromData(Komu::KOMU_BYTE* p_virtual_data_blocks, Komu::KOMU_UNSIGNED_INT p_virtual_data_blocks_size, Komu::KOMU_BYTE* p_available_data_block_ids, Komu::KOMU_UNSIGNED_INT p_available_data_block_ids_size);

            /*
                Add / Remove existing virtual data blocks in / from the table
            */
            int RequestVirtualDataBlockID(Komu::KOMU_UNSIGNED_INT& po_data_block_id);
            int ReleaseVirtualDataBlockID(Komu::KOMU_UNSIGNED_INT p_data_block_id);
            int SetVirtualDataBlock(Komu::ClVirtualDataBlock& p_data_block, Komu::KOMU_UNSIGNED_INT p_data_block_id);
    };
}