#pragma once
#include <cstdint>

namespace Komu
{
    typedef std::uint32_t KOMU_UNSIGNED_INT;
    typedef std::uint64_t KOMU_UNSIGNED_LONG;

    /*
        This member is signed , because a a negative value 
        for member means the block is obsolete & can be re-used.
        Using this, we can save an 8 bits boolean flag
    */
    typedef std::int16_t KOMU_DATA_TABLE_ID;

    typedef std::uint8_t KOMU_BOOL;
    typedef std::uint8_t KOMU_BYTE;

    const std::size_t DEFAULT_BLOCK_TO_RESERVE_WHEN_INITIALIZING = 256;
    const std::uint8_t VERSION = 1;

    struct FILE_HEADER
    {
        KOMU_UNSIGNED_INT m_version;

        KOMU_UNSIGNED_INT m_virtual_address_table_number_of_blocks;
        KOMU_UNSIGNED_INT m_virtual_address_table_number_of_available_block;

        KOMU_UNSIGNED_INT m_number_of_data_tables;
    };

    struct DATA_TABLE_HEADER
    {
        KOMU_UNSIGNED_LONG m_data_table_memory_pool_size;
        KOMU_UNSIGNED_LONG m_data_table_next_available_address;
    };
}

