#pragma once
#include "Globals.hpp"

namespace Komu
{
    class ClVirtualDataBlock
    {
        public:
            Komu::KOMU_DATA_TABLE_ID m_data_table_id;
            Komu::KOMU_UNSIGNED_INT m_allocated_size_in_data_table;
            Komu::KOMU_UNSIGNED_INT m_allocated_buffer_offset_in_data_table;

            bool operator < (const Komu::ClVirtualDataBlock& str) const;
            ClVirtualDataBlock();
            ~ClVirtualDataBlock();

            bool IsObsolete();
            void SetAsObsolete();
            void SetAsNonObsolete();
    };
}