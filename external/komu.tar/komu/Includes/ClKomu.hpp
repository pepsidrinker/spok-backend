#pragma once
#include "Globals.hpp"
#include "ClVirtualDataBlock.hpp"
#include "ClVirtualAddressTable.hpp"
#include "ClDataTable.hpp"
#include <cstring>
#include <mutex>
#include <shared_mutex>
#include <algorithm>
#include <memory>
#include <fstream>
#include <deque>
#include <numeric>
#include <iterator>


namespace Komu
{
    class ClKomu
    {
        public:
            //Used for LoadFromFile() &  SaveToFile()
            std::mutex m_file_mutex;      



            //1 shared mutex for every data table.
            std::vector< std::unique_ptr<std::shared_mutex> > m_data_tables_structure_mutexes;

            std::shared_mutex m_virtual_address_table_structure_mutex;

            std::vector< std::unique_ptr<std::shared_mutex> > m_data_block_mutexes;

            std::vector< std::shared_ptr<Komu::ClDataTable> > m_data_tables;

            std::shared_ptr<Komu::ClVirtualAddressTable> m_virtual_address_table;


            bool m_flag_is_usable;

            
            int TranslateVirtualBufferAddressToRealMemory(Komu::KOMU_UNSIGNED_INT p_virtual_buffer_id, Komu::KOMU_BYTE*& p_pointer);

            //For debugging purposes only, can be deleted on production
            int CRC16(void* p_buffer, int p_buffer_size);
            int GetVirtualBufferCRC16(Komu::KOMU_UNSIGNED_INT p_virtual_buffer_id);            

            /*
                Create a virtual buffer for the user in a specific data table
            */
            int CreateVirtualBufferFromDataTableID(Komu::KOMU_UNSIGNED_INT p_datatable_id , Komu::KOMU_UNSIGNED_INT p_allocated_size, Komu::KOMU_UNSIGNED_INT& po_virtual_buffer_id);

        public:
            bool m_auto_expend_data_table_buffer_size_when_required;

            ClKomu(std::shared_ptr<Komu::ClVirtualAddressTable> p_virtual_address_table, std::vector< std::shared_ptr<Komu::ClDataTable> >& p_data_tables);
            ~ClKomu();

            bool IsUsable();


            /*
                Create a virtual buffer for the user in a specific data table group
            */
            int CreateVirtualBufferFromDataTableGroup(std::vector<Komu::KOMU_UNSIGNED_INT>& p_data_table_ids , Komu::KOMU_UNSIGNED_INT p_allocated_size, Komu::KOMU_UNSIGNED_INT& po_virtual_buffer_id);


            /*
                Create a virtual buffer for the user in a specific data table
            */
            int CreateVirtualBufferFromDataTable(std::shared_ptr<Komu::ClDataTable> p_data_table , Komu::KOMU_UNSIGNED_INT p_allocated_size, Komu::KOMU_UNSIGNED_INT& po_virtual_buffer_id);



            /*
                Create a virtual buffer for the user : meaning a new VirtualDataBlock in the VirtualDataTable, having an allocated space in the data table 
            */
            int CreateVirtualBuffer(Komu::KOMU_UNSIGNED_INT p_allocated_size, Komu::KOMU_UNSIGNED_INT& po_virtual_buffer_id);

            /*
                Provides a way to delete a user's virtual buffer : meaning it will mark the VirtualDataBlock pointed by the virtual buffer as obsolete
            */
            int DeleteVirtualBuffer(Komu::KOMU_UNSIGNED_INT po_virtual_buffer_id);

            /*
                Write into the virtual buffer's real memory address.
            */
            int SetVirtualBufferData(Komu::KOMU_UNSIGNED_INT p_virtual_buffer_id, void* p_data, Komu::KOMU_UNSIGNED_INT p_data_size);
            int SetVirtualBufferData(Komu::KOMU_UNSIGNED_INT p_virtual_buffer_id, unsigned char p_value);            

            /*
                Write into the virtual buffer's real memory address.
                If an auto-expend happens, the last parameter specify the data tables into which expenntion is permitted.
            */
            int SetVirtualBufferData(Komu::KOMU_UNSIGNED_INT p_virtual_buffer_id, void* p_data, Komu::KOMU_UNSIGNED_INT p_data_size, std::vector< Komu::KOMU_UNSIGNED_INT>& p_permitted_data_table_ids_for_auto_expend);

            /*
                Read from the virtual buffer's real memory address.
            */        
            int GetVirtualBufferData(Komu::KOMU_UNSIGNED_INT p_virtual_buffer_id, void*& po_data, Komu::KOMU_UNSIGNED_INT p_data_size, Komu::KOMU_UNSIGNED_INT& po_written_size);
            
            /*
                Return a vector containing all the used virtual data block id
            */
            std::vector<Komu::KOMU_UNSIGNED_INT> GetAllAllocatedVirtualBufferIDs();

            int DefragmentDataTable(Komu::KOMU_UNSIGNED_INT p_data_table_id);
            int Defragment();
            int ShrinkAllocatedMemoryToFit(Komu::KOMU_UNSIGNED_INT p_data_table_id, Komu::KOMU_UNSIGNED_LONG p_extra_memory_size=0);
            int ShrinkAllocatedMemoryToFit(Komu::KOMU_UNSIGNED_LONG p_extra_memory_size=0);

            //int SavetoFile(std::ofstream& p_stream);
            //int LoadFromFile(std::ifstream& p_stream);

            Komu::KOMU_UNSIGNED_LONG GetTotalAllocatedMemorySize();
            Komu::KOMU_UNSIGNED_LONG GetAvailableMemorySize();
            Komu::KOMU_UNSIGNED_LONG GetUnavailableMemorySize();
            Komu::KOMU_UNSIGNED_INT GetNumberOfAvailableVirtualBuffers();
            Komu::KOMU_UNSIGNED_INT GetNumberOfUnavailableVirtualBuffers();
            Komu::KOMU_UNSIGNED_INT GetTotalNumberOfVirtualBuffers();

            //This method is for debug purpose only, delete it when in prod mode
            void hexdump();            
    };
}


