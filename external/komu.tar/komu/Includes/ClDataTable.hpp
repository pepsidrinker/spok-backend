#pragma once
#include "Globals.hpp"
#include <mutex>
#include <cstring>
#include <memory>

namespace Komu
{
    class ClDataTable
    {
        friend class ClKomu;
        
        private:
            std::unique_ptr<Komu::KOMU_BYTE[]> m_memory_pool;
            Komu::KOMU_UNSIGNED_LONG m_next_available_address;
            Komu::KOMU_UNSIGNED_LONG m_memory_pool_size;

        public:

            ClDataTable();
            ~ClDataTable();
            bool IsInitialized();
            int Initialize(Komu::KOMU_UNSIGNED_LONG p_pool_size);
            int Uninitialize();
            int CreateDataBuffer(Komu::KOMU_UNSIGNED_LONG p_allocation_size, Komu::KOMU_UNSIGNED_INT& po_data_buffer_id);
            int LoadFromData(Komu::KOMU_BYTE* p_memory_pool, Komu::KOMU_UNSIGNED_LONG p_memory_pool_size, Komu::KOMU_UNSIGNED_LONG p_next_available_address);
            Komu::KOMU_UNSIGNED_LONG GetAvailableMemorySize();
            Komu::KOMU_UNSIGNED_LONG GetUnavailableMemorySize();
            int HookDataWillBeChanged();
            int HookDataHasChanged();
    };
}