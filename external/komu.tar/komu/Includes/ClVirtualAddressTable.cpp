#include "ClVirtualAddressTable.hpp"

using namespace Komu;

ClVirtualAddressTable::ClVirtualAddressTable(Komu::KOMU_UNSIGNED_INT p_number_of_virtual_data_block)
{
    this->m_flag_is_usable = false;
    if(p_number_of_virtual_data_block == 0)
    {
        return;
    }

    this->m_data_block_instances.reserve(Komu::DEFAULT_BLOCK_TO_RESERVE_WHEN_INITIALIZING);

    for(Komu::KOMU_UNSIGNED_INT i=0;i<p_number_of_virtual_data_block;i++)
    {
        Komu::ClVirtualDataBlock new_data_block;
        new_data_block.m_allocated_size_in_data_table = 0;
        new_data_block.m_allocated_buffer_offset_in_data_table = 0;
        new_data_block.SetAsObsolete();

        this->m_data_block_instances.push_back(new_data_block);
        this->m_available_data_block_ids.push_back(this->m_data_block_instances.size()-1);
    }

    this->m_flag_is_usable = true;
}

ClVirtualAddressTable::~ClVirtualAddressTable()
{
}

int ClVirtualAddressTable::LoadFromData(Komu::KOMU_BYTE* p_virtual_data_blocks, Komu::KOMU_UNSIGNED_INT p_virtual_data_blocks_size, Komu::KOMU_BYTE* p_available_data_block_ids, Komu::KOMU_UNSIGNED_INT p_available_data_block_ids_size)
{
    if(!this->m_flag_is_usable)
    {
        return -1;
    }

    if(p_virtual_data_blocks == nullptr || p_available_data_block_ids == nullptr)
    {
        return -2;
    } 

    if(p_virtual_data_blocks_size % sizeof(ClVirtualDataBlock) != 0)
    {
        return -3;
    }

    if(p_available_data_block_ids_size % sizeof(KOMU_UNSIGNED_INT) != 0)
    {
        return -4;
    }  

    this->m_flag_is_usable = false;


    KOMU_UNSIGNED_INT number_of_data_block = p_virtual_data_blocks_size / sizeof(ClVirtualDataBlock);
    this->m_data_block_instances.clear();
    for(std::size_t i=0;i<number_of_data_block;i++)
    {
        ClVirtualDataBlock* current_data_block = (ClVirtualDataBlock*)p_virtual_data_blocks;
        current_data_block += i;

        this->m_data_block_instances.push_back(*current_data_block);
    }

    KOMU_UNSIGNED_INT number_of_available_data_block_id = p_available_data_block_ids_size / sizeof(KOMU_UNSIGNED_INT);
    this->m_available_data_block_ids.clear();
    for(std::size_t i=0;i<number_of_available_data_block_id;i++)
    {
        KOMU_UNSIGNED_INT* current_data_block_id = (KOMU_UNSIGNED_INT*)p_available_data_block_ids;
        current_data_block_id += i;

        this->m_available_data_block_ids.push_back(*current_data_block_id);
    }

    this->m_flag_is_usable = true;

    return 1;
}

int ClVirtualAddressTable::RequestVirtualDataBlockID(Komu::KOMU_UNSIGNED_INT& po_data_block_id)
{
    if(!this->m_flag_is_usable)
    {
        return -1;
    }

    if(this->m_available_data_block_ids.size()>0)
    {
        Komu::KOMU_UNSIGNED_INT reused_block_id = this->m_available_data_block_ids[this->m_available_data_block_ids.size()-1];
        po_data_block_id = reused_block_id;
        this->m_available_data_block_ids.pop_back();
        return 1;
    }

    return 0;
}

int ClVirtualAddressTable::ReleaseVirtualDataBlockID(Komu::KOMU_UNSIGNED_INT p_data_block_id)
{
    if(!this->m_flag_is_usable)
    {
        return -1;
    }

    this->m_data_block_instances[p_data_block_id].SetAsObsolete();
    this->m_available_data_block_ids.push_back(p_data_block_id);

    return 1;
}

int ClVirtualAddressTable::SetVirtualDataBlock(ClVirtualDataBlock& p_data_block, Komu::KOMU_UNSIGNED_INT p_data_block_id)
{
    if(!this->m_flag_is_usable)
    {
        return -1;
    }

    this->m_data_block_instances[p_data_block_id] =  p_data_block;

    return 1;
}
