#include "ClKomu.hpp"

using namespace Komu;

ClKomu::ClKomu(std::shared_ptr<Komu::ClVirtualAddressTable> p_virtual_address_table, std::vector< std::shared_ptr<Komu::ClDataTable> >& p_data_tables)
{
    this->m_flag_is_usable = false;
    this->m_data_tables = p_data_tables;

    if(p_data_tables.size()==0)
    {
        return;
    }

    this->m_virtual_address_table = p_virtual_address_table;
    this->m_auto_expend_data_table_buffer_size_when_required = true;

    this->m_data_block_mutexes.reserve(p_virtual_address_table->m_data_block_instances.size());
    for(std::size_t i=0;i<p_virtual_address_table->m_data_block_instances.size();i++)
    {
        this->m_data_block_mutexes.emplace_back(std::make_unique<std::shared_mutex>());
    }

    this->m_data_tables_structure_mutexes.reserve(p_data_tables.size());
    for(std::size_t i=0;i<p_data_tables.size();i++)
    {
        this->m_data_tables_structure_mutexes.emplace_back(std::make_unique<std::shared_mutex>());
    }    

    this->m_flag_is_usable = true;
}

ClKomu::~ClKomu()
{
}

bool ClKomu::IsUsable()
{
    return this->m_flag_is_usable && this->m_data_tables.size()>0;
}



int ClKomu::CreateVirtualBufferFromDataTableID(Komu::KOMU_UNSIGNED_INT p_datatable_id , Komu::KOMU_UNSIGNED_INT p_allocated_size, Komu::KOMU_UNSIGNED_INT& po_virtual_buffer_id)
{
    if(!this->IsUsable())
    {
        return -1;
    }   

    //We need a unique_lock because 'CreateDataBuffer' can change the m_data_tables[i]->m_next_available_address member
    std::unique_lock<std::shared_mutex> data_table_guard(*this->m_data_tables_structure_mutexes[p_datatable_id]);    

    //We need a unique_lock because 'RequestVirtualDataBlockID' can change the m_virtual_address_table->m_available_data_block_ids member
    std::unique_lock<std::shared_mutex> virtual_address_table_guard(this->m_virtual_address_table_structure_mutex);    

    Komu::KOMU_UNSIGNED_INT data_table_buffer_address = 0;
    int result =  this->m_data_tables[p_datatable_id]->CreateDataBuffer(p_allocated_size,data_table_buffer_address);
    if(result < 1)
    {
        return -2;
    }

    Komu::KOMU_UNSIGNED_INT new_datablock_id = 0;
    result = this->m_virtual_address_table->RequestVirtualDataBlockID(new_datablock_id);
    if(result < 1)
    {
        return -3;
    }

    Komu::ClVirtualDataBlock new_data_block;
    new_data_block.m_data_table_id = p_datatable_id;
    new_data_block.m_allocated_size_in_data_table = p_allocated_size;
    new_data_block.m_allocated_buffer_offset_in_data_table = data_table_buffer_address;
    new_data_block.SetAsNonObsolete(); 

    std::unique_lock<std::shared_mutex> data_block_guard(*this->m_data_block_mutexes[new_datablock_id]);  
    result = this->m_virtual_address_table->SetVirtualDataBlock(new_data_block, new_datablock_id);
    if(result < 1)
    {
        return -4;
    }



    Komu::KOMU_BYTE* write_address = nullptr;
    if(this->TranslateVirtualBufferAddressToRealMemory(new_datablock_id,write_address) < 1)
    {
        return -5;
    }

    po_virtual_buffer_id = new_datablock_id;  

    return 1;  
}

int ClKomu::CreateVirtualBufferFromDataTableGroup(std::vector<Komu::KOMU_UNSIGNED_INT>& p_data_table_ids , Komu::KOMU_UNSIGNED_INT p_allocated_size, Komu::KOMU_UNSIGNED_INT& po_virtual_buffer_id)
{
    if(!this->IsUsable())
    {
        return -1;
    }

    if(p_data_table_ids.size()==0)
    {
        return -2;
    }


    int result = 0;
    for(std::size_t i=0; i< p_data_table_ids.size(); i++)
    {
        result = this->CreateVirtualBufferFromDataTableID(p_data_table_ids[i],p_allocated_size,po_virtual_buffer_id);
        if(result == 1)
        {
            break;
        }
    }


    return result;    
}

int ClKomu::CreateVirtualBuffer(Komu::KOMU_UNSIGNED_INT p_allocated_size, Komu::KOMU_UNSIGNED_INT& po_virtual_buffer_id)
{
    if(!this->IsUsable())
    {
        return -1;
    }

    /*
        This function will try to allocate a new buffer in a data table.
        If it fails for an unknown reason, it will try with another data table, until it has tried them all.
    */
    int result = 0;
    for(std::size_t i=0; i< this->m_data_tables.size(); i++)
    {
        result = this->CreateVirtualBufferFromDataTableID(i,p_allocated_size,po_virtual_buffer_id);
        if(result == 1)
        {
            break;
        }
    }


    return result;
}

int ClKomu::DeleteVirtualBuffer(Komu::KOMU_UNSIGNED_INT po_virtual_buffer_id)
{
    if(!this->IsUsable())
    {
        return -1;
    }
    
    std::unique_lock<std::shared_mutex> virtual_address_table_guard(this->m_virtual_address_table_structure_mutex);      

    if(this->m_virtual_address_table->ReleaseVirtualDataBlockID(po_virtual_buffer_id)<1)
    {
        return -2;
    }

    return 1;
}

int ClKomu::TranslateVirtualBufferAddressToRealMemory(Komu::KOMU_UNSIGNED_INT p_virtual_buffer_id, Komu::KOMU_BYTE*& p_pointer)
{
    if(!this->IsUsable())
    {
        return -1;
    }

    Komu::KOMU_UNSIGNED_INT data_table_id = this->m_virtual_address_table->m_data_block_instances[p_virtual_buffer_id].m_data_table_id;

    Komu::KOMU_BYTE* minimum_translated_address = this->m_data_tables[data_table_id]->m_memory_pool.get();
    Komu::KOMU_BYTE* maximum_translated_address = minimum_translated_address + this->m_data_tables[data_table_id]->m_memory_pool_size;
    Komu::KOMU_BYTE* wanted_translated_address =  minimum_translated_address + this->m_virtual_address_table->m_data_block_instances[p_virtual_buffer_id].m_allocated_buffer_offset_in_data_table;

    if(wanted_translated_address < minimum_translated_address || wanted_translated_address > maximum_translated_address)
    {
        return -2;
    }

    p_pointer = wanted_translated_address;

    return 1;    
}

int ClKomu::SetVirtualBufferData(Komu::KOMU_UNSIGNED_INT p_virtual_buffer_id, void* p_data, Komu::KOMU_UNSIGNED_INT p_data_size, std::vector< Komu::KOMU_UNSIGNED_INT>& p_permitted_data_table_ids_for_auto_expend)
{
    if(!this->IsUsable())
    {
        return -1;
    }

    if(p_data==nullptr)
    {
        return -2;
    }

    if(p_data_size <=0)
    {
        return -3;
    }

    //TranslateVirtualBufferAddressToRealMemory will access the virtual_address_table
    std::shared_lock<std::shared_mutex> virtual_address_table_lock(this->m_virtual_address_table_structure_mutex);

    if(p_data_size > this->m_virtual_address_table->m_data_block_instances[p_virtual_buffer_id].m_allocated_size_in_data_table)
    {
        if(!this->m_auto_expend_data_table_buffer_size_when_required)
        {
            return -4;
        }

        if(p_permitted_data_table_ids_for_auto_expend.size()==0)
        {
            return -5;
        }

        //We need a unique lock here because m_data_table->CreateDataBuffer will be called
        std::unique_lock<std::shared_mutex> data_block_guard(*this->m_data_block_mutexes[p_virtual_buffer_id]);

        //Komu::KOMU_UNSIGNED_INT data_table_id = this->m_virtual_address_table->m_data_block_instances[p_virtual_buffer_id].m_data_table_id;                 

 
        

        //Re-allocate a new buffer having the correct size. Old data will be deleted on Defragment()
        Komu::KOMU_UNSIGNED_INT data_table_buffer_address = 0;

        int result = 0;
        bool flag_sucessfully_create_datatable_buffer = false;
        for(std::size_t i=0; i< p_permitted_data_table_ids_for_auto_expend.size(); i++)
        {
            std::unique_lock<std::shared_mutex> data_table_guard(*this->m_data_tables_structure_mutexes[p_permitted_data_table_ids_for_auto_expend[i]]);         
            result =  this->m_data_tables[p_permitted_data_table_ids_for_auto_expend[i]]->CreateDataBuffer(p_data_size,data_table_buffer_address);
            if(result == 1)
            {
                this->m_virtual_address_table->m_data_block_instances[p_virtual_buffer_id].m_data_table_id = p_permitted_data_table_ids_for_auto_expend[i];
                this->m_virtual_address_table->m_data_block_instances[p_virtual_buffer_id].m_allocated_buffer_offset_in_data_table = data_table_buffer_address;
                this->m_virtual_address_table->m_data_block_instances[p_virtual_buffer_id].m_allocated_size_in_data_table = p_data_size;                
                flag_sucessfully_create_datatable_buffer = true;
                break;
            } 
        }    

        if(!flag_sucessfully_create_datatable_buffer)
        {
            return -5;
        }
    }

    Komu::KOMU_BYTE* write_address = nullptr;
    if(this->TranslateVirtualBufferAddressToRealMemory(p_virtual_buffer_id,write_address) < 1)
    {
        return -6;
    }

    /* 
        Leave this check here : it fixes a bug where GetVirtualBufferData still uses the full allocated size, even though we just set a subset of it
    */
    if(this->m_virtual_address_table->m_data_block_instances[p_virtual_buffer_id].m_allocated_size_in_data_table > p_data_size)
    {
        this->m_virtual_address_table->m_data_block_instances[p_virtual_buffer_id].m_allocated_size_in_data_table = p_data_size;
    }    

    std::memcpy(write_address,p_data, p_data_size);

    return 1;    
}

int ClKomu::SetVirtualBufferData(Komu::KOMU_UNSIGNED_INT p_virtual_buffer_id, unsigned char p_value)
{
    if(!this->IsUsable())
    {
        return -1;
    }

    //TranslateVirtualBufferAddressToRealMemory will access the virtual_address_table
    std::shared_lock<std::shared_mutex> virtual_address_table_lock(this->m_virtual_address_table_structure_mutex);
    std::unique_lock<std::shared_mutex> data_block_guard(*this->m_data_block_mutexes[p_virtual_buffer_id]);


    Komu::KOMU_UNSIGNED_INT data_table_id = this->m_virtual_address_table->m_data_block_instances[p_virtual_buffer_id].m_data_table_id;    

    if(this->m_data_tables[data_table_id]->HookDataWillBeChanged()<1)
    {
        return -2;
    }
    
    Komu::KOMU_BYTE* write_address = nullptr;
    if(this->TranslateVirtualBufferAddressToRealMemory(p_virtual_buffer_id,write_address) < 1)
    {
        return -3;
    }


    std::memset(write_address,p_value,this->m_virtual_address_table->m_data_block_instances[p_virtual_buffer_id].m_allocated_size_in_data_table); 

    return this->m_data_tables[data_table_id]->HookDataHasChanged();   
}

int ClKomu::SetVirtualBufferData(Komu::KOMU_UNSIGNED_INT p_virtual_buffer_id, void* p_data, Komu::KOMU_UNSIGNED_INT p_data_size)
{
    std::vector<Komu::KOMU_UNSIGNED_INT> data_table_ids(this->m_data_tables.size());
    std::iota (std::begin(data_table_ids), std::end(data_table_ids), 0);

    return this->SetVirtualBufferData(p_virtual_buffer_id,p_data, p_data_size,data_table_ids);
}


int ClKomu::GetVirtualBufferData(Komu::KOMU_UNSIGNED_INT p_virtual_buffer_id, void*& po_data, Komu::KOMU_UNSIGNED_INT p_data_size, Komu::KOMU_UNSIGNED_INT& po_written_size)
{    
    if(!this->IsUsable())
    {
        return -1;
    }

    if(po_data==nullptr)
    {
        return -2;
    }   

    
    //TranslateVirtualBufferAddressToRealMemory will access the virtual_address_table
    std::shared_lock<std::shared_mutex> virtual_address_table_lock(this->m_virtual_address_table_structure_mutex);
    std::shared_lock<std::shared_mutex> data_block_guard(*this->m_data_block_mutexes[p_virtual_buffer_id]); 

    Komu::KOMU_UNSIGNED_INT data_table_id = this->m_virtual_address_table->m_data_block_instances[p_virtual_buffer_id].m_data_table_id;
    std::shared_lock<std::shared_mutex> data_table_guard(*this->m_data_tables_structure_mutexes[data_table_id]);   
     

    Komu::KOMU_BYTE* virtual_buffer_real_address = nullptr;
    if(this->TranslateVirtualBufferAddressToRealMemory(p_virtual_buffer_id,virtual_buffer_real_address)<1)
    {
        return -4;
    }

    Komu::KOMU_UNSIGNED_INT smallest_allocation_size = this->m_virtual_address_table->m_data_block_instances[p_virtual_buffer_id].m_allocated_size_in_data_table;
    if(p_data_size < this->m_virtual_address_table->m_data_block_instances[p_virtual_buffer_id].m_allocated_size_in_data_table)
    {
        smallest_allocation_size = p_data_size;
    }

    

    std::memcpy(po_data,virtual_buffer_real_address,smallest_allocation_size);
    po_written_size = smallest_allocation_size;


    return 1;
}

std::vector<Komu::KOMU_UNSIGNED_INT> ClKomu::GetAllAllocatedVirtualBufferIDs()
{
    std::shared_lock<std::shared_mutex> virtual_address_table_guard(this->m_virtual_address_table_structure_mutex);

    std::vector<Komu::KOMU_UNSIGNED_INT> all_block_ids(this->m_virtual_address_table->m_data_block_instances.size());
    std::iota(std::begin(all_block_ids), std::end(all_block_ids),0);

    std::vector<Komu::KOMU_UNSIGNED_INT> available_block_ids = this->m_virtual_address_table->m_available_data_block_ids;
    std::sort(available_block_ids.begin(), available_block_ids.end());

    std::vector<Komu::KOMU_UNSIGNED_INT> all_used_block_ids;

    std::set_difference (all_block_ids.begin(), all_block_ids.end(), available_block_ids.begin(), available_block_ids.end(), std::inserter(all_used_block_ids, all_used_block_ids.begin()));

    return all_used_block_ids;
}

int ClKomu::Defragment()
{
    if(!this->IsUsable())
    {
        return -1;
    }

    int result = 0;
    for(std::size_t i=0;i<this->m_data_tables.size();i++)
    {
        result = this->DefragmentDataTable(i);
        if(result != 1)
        {
            return result;
        }
    }    

    return 1;
}

int ClKomu::DefragmentDataTable(Komu::KOMU_UNSIGNED_INT p_data_table_id)
{
    if(!this->IsUsable())
    {
        return -1;
    }
        
    std::unique_lock<std::shared_mutex> data_table_guard(*this->m_data_tables_structure_mutexes[p_data_table_id]);
    std::unique_lock<std::shared_mutex> virtual_address_table_guard(this->m_virtual_address_table_structure_mutex);

    //Lock all the blocks in the VirtualAddressTable
    std::deque<std::unique_ptr<std::unique_lock<std::shared_mutex>>> locks;
    for(std::size_t i=0;i<this->m_data_block_mutexes.size();i++)
    {
        if(this->m_virtual_address_table->m_data_block_instances[i].m_data_table_id == p_data_table_id)
        {
            locks.emplace_back ( std::make_unique<std::unique_lock<std::shared_mutex>>(*this->m_data_block_mutexes[i]) );
        }
    }

    //We need to sort the virtual data blocks by order of m_allocated_buffer_offset_in_data_table, ASC
    std::vector< std::pair<Komu::KOMU_UNSIGNED_INT,Komu::KOMU_UNSIGNED_INT> > data_table_offset_and_data_block_id_pairs;
    for(size_t i=0;i<this->m_virtual_address_table->m_data_block_instances.size();i++)
    {
        if(this->m_virtual_address_table->m_data_block_instances[i].m_data_table_id == p_data_table_id)
        {        
            data_table_offset_and_data_block_id_pairs.push_back(std::make_pair(this->m_virtual_address_table->m_data_block_instances[i].m_allocated_buffer_offset_in_data_table,i));
        }
    }

    std::sort(data_table_offset_and_data_block_id_pairs.begin(), data_table_offset_and_data_block_id_pairs.end());

    //Second, defragment the DataTable
    Komu::KOMU_BYTE* data_table_current_position = this->m_data_tables[p_data_table_id]->m_memory_pool.get();

    for(std::size_t i=0;i<data_table_offset_and_data_block_id_pairs.size();i++)
    {
        Komu::ClVirtualDataBlock& current_data_block = this->m_virtual_address_table->m_data_block_instances[data_table_offset_and_data_block_id_pairs[i].second];
        if(current_data_block.IsObsolete())
        {
            continue;
        }
    
        Komu::KOMU_BYTE* block_start_position = this->m_data_tables[p_data_table_id]->m_memory_pool.get();
        block_start_position += current_data_block.m_allocated_buffer_offset_in_data_table;

        if(block_start_position != data_table_current_position)
        {
            //Copy the block to a previous position in the same DataTable
            std::memcpy(data_table_current_position,block_start_position,current_data_block.m_allocated_size_in_data_table);

            //Tell our VirtualDatablock our new address offset in the DataTable         
            this->m_virtual_address_table->m_data_block_instances[data_table_offset_and_data_block_id_pairs[i].second].m_allocated_buffer_offset_in_data_table = data_table_current_position - this->m_data_tables[p_data_table_id]->m_memory_pool.get();
        }

        data_table_current_position += current_data_block.m_allocated_size_in_data_table;

    }

    this->m_data_tables[p_data_table_id]->m_next_available_address = data_table_current_position - this->m_data_tables[p_data_table_id]->m_memory_pool.get();

    return 1;
}

Komu::KOMU_UNSIGNED_LONG ClKomu::GetAvailableMemorySize()
{
    if(!this->IsUsable())
    {
        return 0;
    }

    Komu::KOMU_UNSIGNED_LONG available_memory = 0;
    for(std::size_t i=0;i<this->m_data_tables.size();i++)
    {
        std::shared_lock<std::shared_mutex> data_table_guard(*this->m_data_tables_structure_mutexes[i]);
        available_memory += this->m_data_tables[i]->GetAvailableMemorySize();
    }

    return available_memory;
}

int ClKomu::ShrinkAllocatedMemoryToFit(Komu::KOMU_UNSIGNED_LONG p_extra_memory_size)
{
    if(!this->IsUsable())
    {
        return -1;
    }

    int result = 0;
    for(std::size_t i=0;i<this->m_data_tables.size();i++)
    {
        result = this->ShrinkAllocatedMemoryToFit(i, p_extra_memory_size);
        if(result != 1)
        {
            return result;
        }
    }    

    return 1;    
}

int ClKomu::ShrinkAllocatedMemoryToFit(Komu::KOMU_UNSIGNED_INT p_data_table_id, Komu::KOMU_UNSIGNED_LONG p_extra_memory_size)
{
    if(!this->IsUsable())
    {
        return -1;
    }

    std::unique_lock<std::shared_mutex> data_table_guard(*this->m_data_tables_structure_mutexes[p_data_table_id]);
    std::unique_lock<std::shared_mutex> virtual_address_table_guard(this->m_virtual_address_table_structure_mutex);

    //Lock all the blocks in the VirtualAddressTable
    std::deque<std::unique_ptr<std::unique_lock<std::shared_mutex>>> locks;
    for(std::size_t i=0;i<this->m_data_block_mutexes.size();i++)
    {
        if(this->m_virtual_address_table->m_data_block_instances[i].m_data_table_id == p_data_table_id)
        {
            locks.emplace_back ( std::make_unique<std::unique_lock<std::shared_mutex>>(*this->m_data_block_mutexes[i]) );
        }
    }

    Komu::KOMU_UNSIGNED_LONG old_data_table_next_available_address = this->m_data_tables[p_data_table_id]->m_next_available_address;
    Komu::KOMU_UNSIGNED_LONG new_data_table_size = this->m_data_tables[p_data_table_id]->m_next_available_address + p_extra_memory_size;
    if(new_data_table_size > 0 && new_data_table_size < this->m_data_tables[p_data_table_id]->m_memory_pool_size)
    {
        std::unique_ptr<Komu::KOMU_BYTE[]> new_memory_pool = std::make_unique<Komu::KOMU_BYTE[]>(new_data_table_size);
        std::memcpy(new_memory_pool.get(),this->m_data_tables[p_data_table_id]->m_memory_pool.get(),new_data_table_size);

        if(this->m_data_tables[p_data_table_id]->Uninitialize() != 1)
        {
            return -2;
        }

        if(this->m_data_tables[p_data_table_id]->Initialize(new_data_table_size) != 1)
        {
            return -3;
        }        

        std::memcpy(this->m_data_tables[p_data_table_id]->m_memory_pool.get(),new_memory_pool.get(),new_data_table_size);        
        this->m_data_tables[p_data_table_id]->m_next_available_address = old_data_table_next_available_address;
    }
    else
    {
        return -4;
    }

    return 1;
}

Komu::KOMU_UNSIGNED_LONG ClKomu::GetUnavailableMemorySize()
{
    if(!this->IsUsable())
    {
        return 0;
    }

    Komu::KOMU_UNSIGNED_LONG unavailable_memory = 0;
    for(std::size_t i=0;i<this->m_data_tables.size();i++)
    {
        std::shared_lock<std::shared_mutex> data_table_guard(*this->m_data_tables_structure_mutexes[i]);
        unavailable_memory += this->m_data_tables[i]->GetUnavailableMemorySize();
    }

    return unavailable_memory;
}

Komu::KOMU_UNSIGNED_LONG ClKomu::GetTotalAllocatedMemorySize()
{
    if(!this->IsUsable())
    {
        return 0;
    }

    Komu::KOMU_UNSIGNED_LONG total_memory = 0;
    for(std::size_t i=0;i<this->m_data_tables.size();i++)
    {
        std::shared_lock<std::shared_mutex> data_table_guard(*this->m_data_tables_structure_mutexes[i]);
        total_memory += this->m_data_tables[i]->m_memory_pool_size;
    }   

    return total_memory; 
}

Komu::KOMU_UNSIGNED_INT ClKomu::GetNumberOfAvailableVirtualBuffers()
{
    if(!this->IsUsable())
    {
        return 0;
    }

    std::shared_lock<std::shared_mutex> data_table_guard(this->m_virtual_address_table_structure_mutex);
    return this->m_virtual_address_table->m_available_data_block_ids.size();    
}

Komu::KOMU_UNSIGNED_INT ClKomu::GetNumberOfUnavailableVirtualBuffers()
{
    if(!this->IsUsable())
    {
        return 0;
    }

    std::shared_lock<std::shared_mutex> data_table_guard(this->m_virtual_address_table_structure_mutex);
    return this->m_virtual_address_table->m_data_block_instances.size() - this->m_virtual_address_table->m_available_data_block_ids.size();    
}

Komu::KOMU_UNSIGNED_INT ClKomu::GetTotalNumberOfVirtualBuffers()
{
    if(!this->IsUsable())
    {
        return 0;
    }

    std::shared_lock<std::shared_mutex> data_table_guard(this->m_virtual_address_table_structure_mutex);
    return this->m_virtual_address_table->m_data_block_instances.size();
}


int ClKomu::GetVirtualBufferCRC16(Komu::KOMU_UNSIGNED_INT p_virtual_buffer_id)
{
    if(!this->IsUsable())
    {
        return -1;
    }

    //TranslateVirtualBufferAddressToRealMemory will access the virtual_address_table
    std::shared_lock<std::shared_mutex> virtual_address_table_lock(this->m_virtual_address_table_structure_mutex);

    Komu::KOMU_UNSIGNED_INT data_table_id = this->m_virtual_address_table->m_data_block_instances[p_virtual_buffer_id].m_data_table_id;
    std::shared_lock<std::shared_mutex> data_block_guard(*this->m_data_block_mutexes[data_table_id]);      

    Komu::KOMU_BYTE* virtual_buffer_real_address = nullptr;
    if(this->TranslateVirtualBufferAddressToRealMemory(p_virtual_buffer_id,virtual_buffer_real_address)<1)
    {
        return -4;
    }
    
    return this->CRC16(virtual_buffer_real_address,this->m_virtual_address_table->m_data_block_instances[p_virtual_buffer_id].m_allocated_size_in_data_table);
             
}


// int ClKomu::LoadFromFile(std::ifstream& p_stream)
// {
//     if(!this->IsUsable())
//     {
//         return -1;
//     } 

//     if(!p_stream.is_open())
//     {
//         return -2;
//     }     

//     /*
//         Say that we will be writing our data tables, so now one will be able to read/write into them.
//     */
//     for(std::size_t i=0;i<this->m_data_tables_structure_mutexes.size();i++)
//     {
//         std::unique_lock<std::shared_mutex> data_table_guard(*this->m_data_tables_structure_mutexes[i]);
//     }
    
//     std::unique_lock<std::shared_mutex> virtual_address_table_guard(this->m_virtual_address_table_structure_mutex);

//     Komu::FILE_HEADER file_header;   
//     p_stream.read((char*)&file_header, sizeof(file_header));
//     if (!p_stream) 
//     {
//        return -3;
//     }  


//     std::size_t virtual_address_table_data_blocks_size = file_header.m_virtual_address_table_number_of_blocks * sizeof(Komu::ClVirtualDataBlock);
//     std::unique_ptr<Komu::KOMU_BYTE[]> virtual_address_table_available_blocks( new KOMU_BYTE[virtual_address_table_data_blocks_size]);

//     //std::cout << "I will allocate space for " << file_header.m_virtual_address_table_number_of_blocks << " VDATA blocks" << std::endl;
//     p_stream.read((char*)virtual_address_table_available_blocks.get(),virtual_address_table_data_blocks_size);
//     if (!p_stream) 
//     {
//        return -4;
//     }     

//     std::size_t virtual_address_table_data_block_ids_size = file_header.m_virtual_address_table_number_of_available_block * sizeof(Komu::KOMU_UNSIGNED_INT);
//     std::unique_ptr<Komu::KOMU_BYTE[]> virtual_address_table_available_block_ids( new KOMU_BYTE[virtual_address_table_data_block_ids_size]);

//     //std::cout << "I will allocate space for " << file_header.m_virtual_address_table_number_of_available_block << " VDATA IDs" << std::endl;
//     p_stream.read((char*)virtual_address_table_available_block_ids.get(),virtual_address_table_data_block_ids_size);
//     if (!p_stream) 
//     {
//        return -5;
//     } 

    
//     //Since we unique-locked this->m_virtual_address_table_structure_mutex , any functions wanting to READ in the virtual address table after that call will fail.
//     //However, some other thread might still be writting / reading a single block : 
//     //Thus , we temporarly unique-LOCK / UNLOCK all data blocks in the virtual address table, and by doing so, 
//     //we make sure that we waited until not one is writting in those blocks. 
//     //It is ok the lock to be released as as soon as it has been locked.
    
//     for(std::size_t i=0;i<this->m_data_block_mutexes.size();i++)
//     {
//         std::unique_lock<std::shared_mutex> temporary_lock (*this->m_data_block_mutexes[i]);
//     }


     
//     //First, let populate our VirtualAddressTable
//     if(virtual_address_table_data_blocks_size % sizeof(ClVirtualDataBlock) != 0)
//     {
//         return -6;
//     }

//     if(virtual_address_table_data_block_ids_size % sizeof(KOMU_UNSIGNED_INT) != 0)
//     {
//         return -7;
//     }  


//     this->m_virtual_address_table->m_flag_is_usable = 0;


//     KOMU_UNSIGNED_INT number_of_data_block = virtual_address_table_data_blocks_size / sizeof(ClVirtualDataBlock);
//     this->m_virtual_address_table->m_data_block_instances.clear();
//     this->m_virtual_address_table->m_data_block_instances.reserve(number_of_data_block);
//     for(std::size_t i=0;i<number_of_data_block;i++)
//     {
//         ClVirtualDataBlock* current_data_block = (ClVirtualDataBlock*)virtual_address_table_available_blocks.get();
//         current_data_block += i;

//         this->m_virtual_address_table->m_data_block_instances.push_back(*current_data_block);
//     }
//     virtual_address_table_available_blocks.release();



//     KOMU_UNSIGNED_INT number_of_available_data_block_id = virtual_address_table_data_block_ids_size / sizeof(KOMU_UNSIGNED_INT);
//     this->m_virtual_address_table->m_available_data_block_ids.clear();
//     this->m_virtual_address_table->m_available_data_block_ids.reserve(number_of_available_data_block_id);
//     for(std::size_t i=0;i<number_of_available_data_block_id;i++)
//     {
//         KOMU_UNSIGNED_INT* current_data_block_id = (KOMU_UNSIGNED_INT*)virtual_address_table_available_block_ids.get();
//         current_data_block_id += i;

//         this->m_virtual_address_table->m_available_data_block_ids.push_back(*current_data_block_id);
//     }
//     virtual_address_table_available_block_ids.release();

//     this->m_data_block_mutexes.clear();
//     this->m_data_block_mutexes.reserve(this->m_virtual_address_table->m_data_block_instances.size());
//     for(std::size_t i=0;i<this->m_virtual_address_table->m_data_block_instances.size();i++)
//     {
//         this->m_data_block_mutexes.emplace_back(std::make_unique<std::shared_mutex>());
//     }    

//     this->m_virtual_address_table->m_flag_is_usable = 1; 


//     this->m_data_tables.reserve(file_header.m_number_of_data_tables);   

//     //Now, let's populate our DataTable
//     for(std::size_t i=0;i<file_header.m_number_of_data_tables;i++)
//     {
//         Komu::DATA_TABLE_HEADER data_table_header;
//         p_stream.read((char*)&data_table_header,sizeof(data_table_header));
//         if (!p_stream) 
//         {
//             return -8;
//         } 

//         std::unique_ptr<Komu::KOMU_BYTE[]> data_table_memory_pool( new KOMU_BYTE[data_table_header.m_data_table_memory_pool_size]);
//         p_stream.read((char*)data_table_memory_pool.get(),data_table_header.m_data_table_memory_pool_size);
//         if (!p_stream) 
//         {
//             return -9;
//         }     

//         Komu::KOMU_BYTE* new_memory_pool = new Komu::KOMU_BYTE[data_table_header.m_data_table_memory_pool_size];
//         this->m_data_tables[i]->m_memory_pool = new_memory_pool;
//         this->m_data_tables[i]->m_memory_pool_size = data_table_header.m_data_table_memory_pool_size;
//         this->m_data_tables[i]->m_next_available_address = data_table_header.m_data_table_next_available_address;

//         if(data_table_header.m_data_table_next_available_address > 0)
//         {
//             std::memcpy(new_memory_pool,data_table_memory_pool.get(),data_table_header.m_data_table_memory_pool_size);
//         }
//     }


//     return 1;  
// }


// int ClKomu::SavetoFile(std::ofstream& p_stream)
// {
//     if(!this->IsUsable())
//     {
//         return -1;
//     }

//     if(!p_stream.is_open())
//     {
//         return -2;
//     }

//     /*
//         Say that we will be reading our data tables, so now one will be able to write into them.
//     */
//     for(std::size_t i=0;i<this->m_data_tables_structure_mutexes.size();i++)
//     {
//         std::shared_lock<std::shared_mutex> data_table_guard(*this->m_data_tables_structure_mutexes[i]);
//     }
    
//     std::shared_lock<std::shared_mutex> virtual_address_table_guard(this->m_virtual_address_table_structure_mutex);

//     std::deque<std::unique_ptr<std::shared_lock<std::shared_mutex>>> locks;
//     for(std::size_t i=0;i<this->m_data_block_mutexes.size();i++)
//     {
//         locks.emplace_back ( std::make_unique<std::shared_lock<std::shared_mutex>>(*this->m_data_block_mutexes[i]) );
//     }    

//     Komu::FILE_HEADER file_header;
//     file_header.m_version = Komu::VERSION;
//     file_header.m_virtual_address_table_number_of_blocks = this->m_virtual_address_table->m_data_block_instances.size();
//     file_header.m_virtual_address_table_number_of_available_block = this->m_virtual_address_table->m_available_data_block_ids.size();
//     file_header.m_number_of_data_tables = this->m_data_tables.size();

//     //Write the headers
//     p_stream.write((const char*)&file_header,sizeof(file_header));
//     if(!p_stream)
//     {
//         return -3;
//     }

//     //Write the virtual address table data
//     p_stream.write((const char*)this->m_virtual_address_table->m_data_block_instances.data(),sizeof(Komu::ClVirtualDataBlock) * this->m_virtual_address_table->m_data_block_instances.size());
//     p_stream.write((const char*)this->m_virtual_address_table->m_available_data_block_ids.data(),sizeof(Komu::KOMU_UNSIGNED_INT) * this->m_virtual_address_table->m_available_data_block_ids.size());  
//     if(!p_stream)
//     {
//         return -4;
//     }      

//     //Write the data tables' data
//     for(std::size_t i=0;i<this->m_data_tables.size();i++)
//     {        
//         Komu::DATA_TABLE_HEADER data_table_header;
//         data_table_header.m_data_table_memory_pool_size = this->m_data_tables[i]->m_memory_pool_size;
//         data_table_header.m_data_table_next_available_address = this->m_data_tables[i]->m_next_available_address;
//         p_stream.write((const char*)&data_table_header,sizeof(data_table_header));
//         p_stream.write((const char*)this->m_data_tables[i]->m_memory_pool, this->m_data_tables[i]->m_memory_pool_size);
//         if(!p_stream)
//         {
//             return -5-i;
//         }                
//     }

//     return 1;
// }

/*
void ClKomu::hexdump() 
{
unsigned char *buf = (unsigned char*)this->m_data_table->m_memory_pool;
int buflen = this->m_data_table->m_memory_pool_size;
int i, j;
for (i=0; i<buflen; i+=16) {
    printf("%06x: ", i);
    for (j=0; j<16; j++) 
    if (i+j < buflen)
        printf("%02x ", buf[i+j]);
    else
        printf("   ");
    printf(" ");
    for (j=0; j<16; j++) 
    if (i+j < buflen)
        printf("%c", isprint(buf[i+j]) ? buf[i+j] : '.');
    printf("\n");
}
}
*/



int ClKomu::CRC16(void* p_buffer, int p_buffer_size)
{
  unsigned char* buf = (unsigned char*)p_buffer;
  int len = p_buffer_size;

  int crc = 0xFFFF;

  for (int pos = 0; pos < len; pos++) 
  {
    crc ^= (int)buf[pos] & 0xFF;   // XOR byte into least sig. byte of crc

    for (int i = 8; i != 0; i--) {    // Loop over each bit
      if ((crc & 0x0001) != 0) {      // If the LSB is set
        crc >>= 1;                    // Shift right and XOR 0xA001
        crc ^= 0xA001;
      }
      else                            // Else LSB is not set
        crc >>= 1;                    // Just shift right
    }
  }
  // Note, this number has low and high bytes swapped, so use it accordingly (or swap bytes)
  return crc;    
}