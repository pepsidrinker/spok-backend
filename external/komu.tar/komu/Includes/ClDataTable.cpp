#include "ClDataTable.hpp"

using namespace Komu;

ClDataTable::ClDataTable()
{
    this->m_next_available_address = 0;
    this->m_memory_pool_size = 0;
    this->m_memory_pool = nullptr;
}

ClDataTable::~ClDataTable()
{
}

bool ClDataTable::IsInitialized()
{
    if(this->m_next_available_address == 0 && this->m_memory_pool == nullptr && this->m_memory_pool_size==0)
    {
        return false;
    }

    return true;
}

int ClDataTable::Initialize(Komu::KOMU_UNSIGNED_LONG p_pool_size)
{
    if(p_pool_size == 0)
    {
        return -1;
    }

    if(this->IsInitialized())
    {
        return -2;
    }

    this->m_memory_pool = std::make_unique<Komu::KOMU_BYTE[]>(p_pool_size);
    this->m_memory_pool_size = p_pool_size;
    std::memset(this->m_memory_pool.get(),0,p_pool_size);    

    return 1;
}
    
int ClDataTable::Uninitialize()
{
    this->m_memory_pool_size = 0;
    this->m_memory_pool = nullptr;
    this->m_next_available_address = 0;

    return 1;
}

int ClDataTable::CreateDataBuffer(Komu::KOMU_UNSIGNED_LONG p_allocation_size, Komu::KOMU_UNSIGNED_INT& po_data_buffer_id)
{
    if(this->m_memory_pool==nullptr)
    {
        return -1;
    }

    //First, try to allocate the memory
    if((p_allocation_size + this->m_next_available_address) > this-> m_memory_pool_size)
    {
        return -2;
    }

    po_data_buffer_id = this->m_next_available_address;
    this->m_next_available_address += p_allocation_size;

    return 1;
}

int ClDataTable::HookDataWillBeChanged()
{
    return 1;
}

int ClDataTable::HookDataHasChanged()
{
    return 1;
}

int ClDataTable::LoadFromData(Komu::KOMU_BYTE* p_memory_pool, Komu::KOMU_UNSIGNED_LONG p_memory_pool_size, Komu::KOMU_UNSIGNED_LONG p_next_available_address)
{
    if(this->IsInitialized())
    {
        if(this->Uninitialize() != 1)
        {
            return -1;
        }
    }

    if(p_memory_pool_size > 0)
    {
        this->m_memory_pool = std::make_unique<Komu::KOMU_BYTE[]>(p_memory_pool_size);
        this->m_memory_pool_size = p_memory_pool_size;
        this->m_next_available_address = p_next_available_address;

        if(p_next_available_address > 0)
        {
            std::memcpy(this->m_memory_pool.get(),p_memory_pool,p_memory_pool_size);
        }
    }

    return 1;
}

Komu::KOMU_UNSIGNED_LONG ClDataTable::GetAvailableMemorySize()
{
    if(this->m_memory_pool==nullptr)
    {
        return 0;
    }

    return this->m_memory_pool_size - this->m_next_available_address;
}


Komu::KOMU_UNSIGNED_LONG ClDataTable::GetUnavailableMemorySize()
{
    if(this->m_memory_pool==nullptr)
    {
        return 0;
    }

    return this->m_next_available_address;
}