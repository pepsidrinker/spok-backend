#include "ClVirtualDataBlock.hpp"

using namespace Komu;


ClVirtualDataBlock::ClVirtualDataBlock()
{
    this->m_data_table_id = 0;
    this->m_allocated_size_in_data_table = 0;
    this->m_allocated_buffer_offset_in_data_table = 0;
    this->m_data_table_id = 0;
}

ClVirtualDataBlock::~ClVirtualDataBlock()
{
}

bool ClVirtualDataBlock::operator < (const Komu::ClVirtualDataBlock& p_item) const
{
    return (this->m_allocated_buffer_offset_in_data_table < p_item.m_allocated_buffer_offset_in_data_table);
}

bool ClVirtualDataBlock::IsObsolete()
{
    return this->m_data_table_id < 0;
}

void ClVirtualDataBlock::SetAsObsolete()
{
    if(this->m_data_table_id > 0)
    {
        this->m_data_table_id *= -1;
    }
}

void ClVirtualDataBlock::SetAsNonObsolete()
{
    if(this->m_data_table_id < 0)
    {
        this->m_data_table_id *= -1;
    }
}